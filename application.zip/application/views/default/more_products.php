<?php
if (isset($product_data) and $product_data != '') {
    foreach ($product_data as $product) {
        $product_featured_image = $this->product->get_product_featured_image($product['product_id']);
        ?>
        <div class="list_bar">
            <div class="pro_img">
                <?php
                $file_path = FCPATH . "assets/uploads/product_images/" . $product_featured_image->image_name;
                if ($product_featured_image->image_name != '' && file_exists($file_path)) {
                    ?>
                    <a class="fancybox" href="<?= $this->config->item('uploads') ?>product_images/<?= $product_featured_image->image_name ?>">
                        <img class="img-responsive" src="<?= $this->config->item('uploads') ?>product_images/<?= $product_featured_image->image_name ?>" alt="<?= $product['product_name'] ?>" >
                    </a>
                <?php } else { ?>
                    <img class="img-responsive" src="<?= site_url('assets/uploads/product_images/image_not_available.jpg') ?>">
                <?php } ?>       
            </div>
            <div class="list_detail">
                <a href="<?= site_url('product/' . $product['slug']) ?>" class="viewdetail">View Detail</a>
                <h2><?= $product['product_title'] ?></h2>
                <div>
                    <span class="code_no">UPC CODE :</span>
                    <span class="code_no"><?= $product['product_upc_code'] ?></span>
                </div>
                <br/>
                <div>
                    <span class="code_no">Product Code :</span>
                    <span class="code_no"><?= $product['product_code'] ?></span>
                </div>
                <div class="color_bar"> 
                    <div class="color">
                        <label>No. of Rooms:</label>
                        <select name="product_color">
                            <option>Select Rooms</option>
                            <?php
                            $product_colors = $product['product_color'];
                            $product_colors = explode(',', $product_colors);
                            foreach ($product_colors as $product_color) {
                                ?>
                                <option value="<?= $product_color ?>"><?= $product_color ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <h3>Product Description :</h3>
                <?= character_limiter($product['product_small_description'], 100); ?>  
<!-- <a href="javascript:;" class="btn btn-primary pull-left addToCompare" data-product_id="<?= $product_detail->product_id; ?>" data-category_id="<?= $product_detail->category_id; ?>" data-product_price="<?= $product_detail->product_price; ?> "data-product_size="<?= $product_detail->product_size; ?>" data-product_color="<?= $product_detail->product_color; ?>">ADD TO COMPARE</a>-->
                 <div class="checkbox">
                     <label><input type="checkbox" name="product_id[]"  id="product_id" value="<?=$product['product_id']?>" <?php if($this->session->userdata('compare_products')){echo in_array($product['product_id'], $this->session->userdata('compare_products'))?'checked':'';} ?>>Add to Compare</label>
                    
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    <?php
    }
} else {
    ?>
    <p>No Products Found</p>
<?php } ?>
<script>
    $(document).ready(function () {
        $('#paging').html('<?= $paging ?>');
    });
</script>