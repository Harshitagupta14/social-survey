<section class="content_section">

    <div class="container" id="scrollToTop">

        <div class="row">

            <?php echo $this->load->view($this->config->item('template') . '/categoryList') ?>

            <div class="device_full2 col-xs-8 col-md-9">

                <div class="alert alert-success" id="successMsg" style="display:none;">

                    <a href="#" class="close" data-dismiss="alert">&times;</a>

                    <strong>Success! </strong> Product Has Been Added To Cart Successfully.

                </div>

                <div class="pro_detail">

                     <?php $this->load->view($this->config->item('template') . '/page_title'); ?>



                    <div class="row">

                        <?php if ($this->session->flashdata('ReviewSuccess')) { ?>  

                            <div class="alert alert-success"> <?= $this->session->flashdata('ReviewSuccess') ?></div>

                        <?php } ?>

                       

                        <div class="col-sm-12 col-md-5">

                            <div class="product_box">

                                <img class="cloudzoom" src="<?= site_url() . image('uploads/product_images/' . $product_featured_image->image_name, array(300, 0)) ?>" data-cloudzoom = "zoomImage: '<?= site_url() . image('uploads/product_images/' . $product_featured_image->image_name, array(0, 0)) ?>',zoomWidth:500,zoomHeight:500,lensWidth:100,lensHeight:100" />

                            </div>

                            <div id="slider1">

                                <div class="thumbelina-but horiz left">&#706;</div>

                                <ul class="thumb_list">

                                    <?php foreach($product_image as $image){?>

                                    <li>

                                        <img class ='cloudzoom-gallery' src="<?= site_url() . image('uploads/product_images/' . $image['image_name'], array(0, 110)) ?>" data-cloudzoom = "useZoom: '.cloudzoom', image: '<?= site_url() . image('uploads/product_images/' . $image['image_name'], array(300, 0)) ?>', zoomImage: '<?= $this->config->item('uploads') . 'product_images/' .$image['image_name'] ?>' " >

                                    </li>

                                    <?php } ?>

                                </ul>

                                <div class="thumbelina-but horiz right">&#707;</div>

                            </div>

                            <div class="clearfix"></div>

                        </div>								   

                        <div class="col-sm-12 col-md-7">

                            <div class="detail_box">

                                <h2><?= $product_detail->product_title; ?> </h2>

                                <div class="db_row"><label>UPC CODE :</label> <label><?= $product_detail->product_upc_code; ?></label></div>

                                <div class="db_row"><label>Product Code :</label> <label><?= $product_detail->product_code; ?></label></div>

                                <!-- <div class="db_row"><label>Product Price :</label> <label><?= $product_detail->product_price; ?></label></div> -->
                                <div class="db_row no-transform">
                                    <label>MRP :</label> <label>Rs <span style="text-decoration:line-through;"><?=$product_detail->product_mrp?></span> <span class="text-primary"><?=$product_detail->product_discount?>% OFF</span></label>
                                    <div class="clearfix"></div>
                                    <label class="text-primary">Save :</label> <label> <span class="text-primary">Rs <?= ($product_detail->product_mrp * $product_detail->product_discount) /100 ?></span></label>
                                    <div class="clearfix"></div>
                                    <label class="text-2x">Pay</label> <label class="text-2x"> Rs <span class="color:#000;"><?= ($product_detail->product_mrp)-($product_detail->product_mrp * $product_detail->product_discount) /100 ?></span></label>
                                </div>

                                <div class="db_row">

                                    <?php if($product_detail->product_color){?>
                                    <label>color:</label>

                                    <select name="product_color" class="color-input">

                                        <option value=''>Select Color</option>

                                        <?php

                                        $product_colors = $product_detail->product_color;

                                        $product_colors = explode(',', $product_colors);

                                        foreach ($product_colors as $product_color) {

                                            ?>

                                            <option value="<?= $product_color ?>"><?= $product_color ?></option>

                                        <?php } ?>

                                    </select>
                                    <?php } ?>
                                    
                                                                        <?php if($product_detail->product_size){?>
                                    <label>Size:</label>

                                    <select name="product_size" class="size-input">

                                        <option value=''>Select Size</option>

                                        <?php

                                        $product_sizes = $product_detail->product_size;

                                        $product_sizes = explode(',', $product_sizes);

                                        foreach ($product_sizes as $product_size) {

                                            ?>

                                            <option value="<?= $product_size ?>"><?= $product_size ?></option>

                                        <?php } ?>

                                    </select>
                                    <?php } ?>

                                    
                                    <input type="hidden" class="form-control" name="product_id" value="<?= $product['product_id'] ?>"/>	

                                </div>

                                <div class="db_row">

                                    <label>Quantity :</label> 

                                    <input type="text" class="quantity" name="quantity" value="1">

                                    <a href="javascript:;" class="increment_qty"><img src="<?= $this->config->item('frontassets') ?>img/plus.png" alt=""></a>

                                    <a href="javascript:;" class="decrement_qty"><img src="<?= $this->config->item('frontassets') ?>img/minus.png" alt=""></a>

                                </div>

                                <div class="clearfix"><br></div>

                                <a href="javascript:;" class="btn btn-primary pull-right addToCart" data-product_id="<?= $product_detail->product_id; ?>" data-category_id="<?= $product_detail->category_id; ?>" data-product_price="<?= $product_detail->product_price; ?> "data-product_size="<?= $product_detail->product_size; ?>" data-product_color="<?= $product_detail->product_color; ?>">ADD TO CART</a>

                                <div class="social-share">
                                    <script type="text/javascript">var switchTo5x = true;</script>
                                    <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
                                    <script type="text/javascript">stLight.options({publisher: "70a158af-d912-451a-b861-11e9211d8764", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
                                    <span class='st_facebook_hcount' displayText='Facebook'></span>
                                    <span class='st_googleplus_hcount' displayText='Google +'></span>
                                    <span class='st_twitter_hcount' displayText='Tweet'></span>
                                </div>

                            </div>

                        </div>				

                        <div class="col-sm-12 col-md-12">

                            <?php echo str_replace("{#review_form}", $review_html, $product_detail->product_description); ?>

                        </div>

                        <div class="col-sm-12 col-md-12">

                            <div class="similar_pro">

                                <h2>Similar Products</h2>

                                <div id="sim_pro_carousel">

                                    <?php

                                    foreach ($similar_product as $product) {

                                        $product_featured_image = $this->product->get_product_featured_image($product['product_id']);

                                        ?>

                                        

                                        <div class="spro">

                                            <?php

                                            $file_path = FCPATH . "assets/uploads/product_images/" . $product_featured_image->image_name;

                                            if ($product_featured_image->image_name != '' && file_exists($file_path)) {

                                                ?>

                                                <a href="<?= site_url('product/' . $product['slug']) ?>" class="scroll-img">



                                                    <img  class="img-responsive"  src="<?= site_url('assets/uploads/product_images/' . $product_featured_image->image_name) ?>" alt="<?= $product['product_name'] ?>" >

                                                </a>

                                            <?php } else { ?>

                                                <a href="<?= site_url('product/' . $product['slug']) ?>">

                                                    <img src="<?= site_url('assets/uploads/product_images/image_not_available.jpg') ?>"  class="img-responsive">                        

                                                </a>

                                            <?php } ?>

                                            <p>Code:<?= $product['product_code']; ?></p>

                                            <a href="<?= site_url('product/' . $product['slug']) ?>"><i class="fa fa-search"></i></a>

                                        </div>

                                    

                                    <?php } ?>

                                </div>

                                    <a href="javascript:void(0);" id="simpro_prev"><i class="fa fa-angle-left"></i></a>

                                    <a href="javascript:void(0);" id="simpro_next"><i class="fa fa-angle-right"></i></a>

                            </div>

                        </div>	

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<script type="text/javascript">

    CloudZoom.quickStart();

</script>    

<script type="text/javascript">

    $(function () {

        $('#slider1').Thumbelina({

            $bwdBut: $('#slider1 .left'), // Selector to left button.

            $fwdBut: $('#slider1 .right')    // Selector to right button.

        });

    })

</script>

<script>

    $('body').delegate('.addToCart', 'click', function () {

        var product_id = $(this).attr('data-product_id');

        var category_id = $(this).attr('data-category_id');

        var product_title = $(this).attr('data-product_title');

        var product_description = $(this).attr('data-product_description');

        var product_upc_code = $(this).attr('data-product_upc_code');

        var product_code = $(this).attr('data-product_code');

        var product_price = $(this).attr('data-product_price');

        var product_color = $(this).parent().parent().find('.color-input').val();
        
         var product_size = $(this).parent().parent().find('.size-input').val();
      //  alert(product_size);

        var quantity = $(this).parent().parent().find('.quantity').val();

        if (quantity != '') {

           // alert(sumit);

            $.ajax({

                type: "POST",

                async: 'false',

                url: baseurl + "add-cart-item",

                // dataType: "html",

                data: {"product_id": product_id, "category_id": category_id, "product_color": product_color, "product_quantity": quantity,"product_size" :product_size},

                success: function () {

                    //alert("Product Added Successfully");

                    $('#successMsg').show().delay(5000).fadeOut();

                    $('html,body').animate({scrollTop: $('#scrollToTop').offset().top},'slow');

                    location.reload();

                }

            })

        }

        else {

            alert("Please Check Fields");

        }

    });

    $("body").delegate(".increment_qty", "click", function () {

        var oldVal = $(this).parent().find(".quantity").val();

        if (parseInt(oldVal) >= 1) {

            var newVal = parseInt(oldVal) + 1;

            $(this).parent().find(".quantity").val(newVal);

        }

    });

    $("body").delegate(".decrement_qty", "click", function () {

        var oldVal = $(this).parent().find(".quantity").val();

        if (parseInt(oldVal) >= 2) {

            var newVal = parseInt(oldVal) - 1;

            $(this).parent().find(".quantity").val(newVal);

        }

    });
    
    

</script>