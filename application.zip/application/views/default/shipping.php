<section class="content_section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 cat_bar">
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <li class="active">Shipping</li>
                </ol>
        <div class="alert alert-success" id="successMsg" style="display:none;">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Success! </strong> Quantity Updated Successfully.
        </div>
        <?php if ($this->session->flashdata('ProductSuccess')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('ProductSuccess') ?></div>
        <?php } ?>
                 <ul class="steps">
            <li>Shopping Cart</li>
            <li class="current">Shipping</li>
            <li>Order Review</li>
            <li>Order Complete</li>
        </ul>
        
        <div class="shipping-form">	
            <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">		
                <div class="clearfix"></div>
                <h3>Shipping Information</h3>
                <hr><br>
            <div class="row">
                <div class="col-md-6">
                    <div class="row form-group">
                        <label for="name" class="nameLabel col-md-3 control-label">First Name:</label>
                        <div class="col-md-9">
                            <input name="first_name" type="text" class="form-control" id="customer_name" placeholder="First Name" required />
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('first_name')) ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name" class="nameLabel col-md-3 control-label">Last Name:</label>
                        <div class="col-md-9">
                            <input name="last_name" type="text" class="form-control" id="customer_name" placeholder="Last Name" required  />
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('last_name')) ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name" class="nameLabel col-sm-3 control-label">Address:</label>
                        <div class="col-md-9">  
                            <input name="address" type="text" class="form-control"  rows="4" cols="18"  id="password" placeholder="Address" required />
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('address')) ?></span>
                        </div>
                    </div>		
                     <div class="form-group">
                        <label for="name" class="nameLabel col-sm-3 control-label">Province:</label>
                        <div class="col-md-9">
                            <select class="form-control select" data-live-search="true" name="province_name" id="province_name" required>  
                                <option value="">Select Province</option>
                                <?php foreach ($province_list as $province) {//pr($province);die; ?>
                                    <option value="<?= $province['province_name'] ?>"><?= $province['province_name'] ?></option>  
                                <?php } ?>
                            </select>
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('province_id')) ?></span>
                        </div>                        
                    </div>		
                    					
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Payment Type: <span class="order_type"></span></label>
                        <div class="col-md-9">
                            <input required type="radio" name="payment_type" value="cash_on_delivery"> Cash On Delivery 
                            <input required type="radio" name="payment_type" value="paypal"> Paypal 
                        </div>
                    </div>
                </div>			
                <div class="col-md-6">
                    <div class="row form-group">
                        <label for="name" class="nameLabel col-md-3 control-label">E-Mail Address:</label>
                        <div class="col-md-9">
                            <input name="email_id" type="text" class="form-control" value="<?=$user_email?>" id="customer_name" placeholder="Email" required />
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('email_id')) ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name" class="nameLabel col-md-3 control-label">Contact Number:</label>
                        <div class="col-md-9">

                            <input name="contact_no" type="text" class="form-control" id="contact_no" placeholder="Contact Number" required  />
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('contact_no')) ?></span>
                        </div>                      
                    </div>					 
                    <div class="row form-group">
                        <label for="name" class="nameLabel col-sm-3 control-label">City:</label>
                        <div class="col-md-9"> <input name="city" type="text" class="form-control"  rows="4" cols="18"  id="city" placeholder="City" required></input>
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('address')) ?></span>
                        </div>
                    </div>
                   			
                    <div class="form-group">
                        <label for="name" class="nameLabel col-sm-3 control-label">Postal Code</label>
                        <div class="col-md-9">
                            <input name="postal_code" type="text" class="form-control"  type="text"  placeholder="Postal Code" required />
                            <span class="help-block" style="color: red;"><?= strip_tags(form_error('postal_code')) ?></span>
                        </div>                       
                    </div>
                    <div class="form-group">           
                        <div class="col-md-12 text-right">
                            <input type="submit" name="submit" class="btn btn-success btn-radius" value="Continue" />
                            <input type="hidden" name="form_submit" value="save" />
                            <input type="hidden" name="customerRegistration" class="cart-btn" value="save" />
                        </div>                    
                    </div>                    
                </div>            
            </div>            
            </form>
        </div>
    </div>
    </div>
    </div>
</section>