<div class="col-sm-12 col-md-3">
    <div class="sidebar">
        <h1>Hotels</h1>
        <ul>
            <?php
            $parent_categories_list = $this->product->get_categories(0);
            foreach ($parent_categories_list as $parent_category) {
                $sub_categories_list = $this->product->get_categories($parent_category['category_id']);
                if ($sub_categories_list) {
                    ?>
                    <li <?= ($parent_category['category_id'] == $category_detail->category_id || $parent_category['category_id'] == $category_detail->parent_id) ? 'class="current"' : '' ?> ><span class="subnav_toggle"><?= $parent_category['category_name'] ?> <i class="fa fa-angle-down"></i></span>
                        <ul class="submenu" <?= ($parent_category['category_id'] == $category_detail->category_id || $parent_category['category_id'] == $category_detail->parent_id) ? 'style="display:block;"' : '' ?>>
                            <?php foreach ($sub_categories_list as $sub_category) { ?>
                                <li>
                                    <a href="<?= site_url('category/' . $sub_category['slug']) ?>"><?= $sub_category['category_name'] ?></a>
                                </li>
                            <?php } ?>

                        </ul>
                    </li>
                <?php } else {
                    ?>
                    <li>
                        <a href="<?= site_url('category/' . $parent_category['slug']) ?>"><?= $parent_category['category_name'] ?></a>
                    </li>
                    <?php
                }
            }
            ?>
        </ul>
        <br>
        <h1>All Product Types</h1>
        <ul>
            <?php
            $product_types_list = $this->product->get_product_types();
            foreach ($product_types_list as $product_type) {
                ?>
                <li><a href="<?= site_url('type/' . $product_type['slug']) ?>"><?= $product_type['prd_type_name'] ?></a></li>
            <?php } ?>
        </ul>
        <?php
        $commercial_banner = $this->common_model->getBannerRecords('3');
        foreach ($commercial_banner as $commercial) {
            ?>
            <div class="add">
                <a href="<?= $commercial['banner_link'] ?>"><img src="<?= $this->config->item('uploads') ?>banner_images/<?= $commercial['banner_image'] ?>" class="img-responsive"></a>
            </div>
        <?php } ?>
    </div>
</div>
