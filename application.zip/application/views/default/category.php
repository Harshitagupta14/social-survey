<section class="content_section">
    <div class="container">
        <div class="row">
            <?php echo $this->load->view($this->config->item('template') . '/categoryList') ?>
            <div class="col-sm-12 col-md-9 cat_bar">
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <?= $breadcrumb ?>
                </ol>
                <div class="grid_bar">
                    <h4><?php echo (!empty($category_detail)) ? $category_detail->category_name : 'Hotels' ?></h4>
                </div>
                <div class="row">
                    <?php
                    if (isset($category_data) && !empty($category_data)) { //pr($category_data);die;
                        foreach ($category_data as $category) {
                            ?>   
                            <div class="col-xs-6 col-md-4">
                                <div class="tab_pro">
                                    <?php
                                    $count_sub_category = $this->common_model->getCountAllFromAnyTable('parent_id', $category->category_id, 'tbl_category', 'active');
                                    $file_path = FCPATH . "assets/uploads/category_images/" . $category->category_image;
                                    if ($category->category_image != '' && file_exists($file_path)) {
                                        ?>
                                        <a class="" href="<?= site_url('category/' . $category->slug) ?>">
                                            <img class="img-responsive" src="<?= $this->config->item('uploads') ?>category_images/<?= $category->category_image ?>" alt="<?= $category->category_name ?>" >
                                        </a>
                                    <?php } else { ?>
                                        <img class="img-responsive" src="<?= site_url('assets/uploads/category_images/image_not_available.jpg') ?>">
                                    <?php } ?>       
                                    <h4><?= $category->category_name ?></h4>									
                                    <a href="<?= site_url('category/' . $category->slug) ?>" class="view">View <?= ($count_sub_category == 0) ? 'Hotels' : 'SubHotels' ?></a>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>