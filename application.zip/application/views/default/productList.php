<section class="content_section">
<div class="mid">

    <div class="container" id="scrollToTop">
        <div class="row">
            <?php echo $this->load->view($this->config->item('template') . '/categoryList') ?>
            <!-- right bar -->
            <div class="col-sm-12 col-md-9 cat_bar">
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <?= $breadcrumb ?>
                </ol>
<?php $compare_products = $this->session->userdata('compare_products');
                    pr($this->session->all_userdata())?>
                <div class="compare-pro">
                    <?php 
                  
      
                  //  pr($compare_products);
                   if (isset($compare_products) and $compare_products != '') {
                 //   foreach($compare_products as $products){
                       $product_featured_image = $this->product->get_product_featured_image($compare_products->product_id);  
                      ?>
                    
                    <div class="com-pro">
                        <img src="<?= $this->config->item('uploads') ?>product_images/<?= $product_featured_image->image_name ?>" alt="product">
                        <span><?= $compare_products->product_title;?></span>
                    </div>
                    <?php }//} ?>
             
                     <a class="btn btn-primary compare-btn" href="#">Compare</a>
                    
                   
                </div>
   <div class="alert alert-success" id="successMsg" style="display:none;">
                    <a href="#" class="close" data-dismiss="alert">&times;</a>
                    <strong>Success! </strong> Product Has Been Added To Cart Successfully.
                </div>
                <div class="grid_bar">
                    <h4><?php echo (!empty($category_detail))?$category_detail->category_name .' Hotels':'' ?></h4>
                    <div class="pull-right">
                        <a href="javascript:;" class="btn btn-primary list_view" id="list_view">List View <i class="fa fa-list"></i></a>
                        <a href="javascript:;" class="btn btn-primary grid_view" id="grid_view">Grid View <i class="fa fa-th"></i></a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div id="my-list" class="list-view"></div>               				
                <div id="paging"></div>	   
            </div>        
        </div>
    </div>
</div>	
</section>
<?= $this->load->view($this->config->item('template') . '/mytable'); ?>
<script>
$("body").delegate(".grid_view", "click", function(e) {
        e.preventDefault();
        $(this).addClass("active");
        $(".list_view").removeClass("active");
        $("#my-list").switchClass("list-view", "grid-view");

    });
    $("body").delegate(".list_view", "click", function(e) {
        e.preventDefault();
        $(this).addClass("active");
        $(".grid_view").removeClass("active");
        $("#my-list").switchClass("grid-view", "list-view");
    });
    $('body').delegate('.addToCart', 'click', function () {
        var product_id = $(this).attr('data-product_id');
        var category_id = $(this).attr('data-category_id');
        var product_title = $(this).attr('data-product_title');
        var product_description = $(this).attr('data-product_description');
        var product_upc_code = $(this).attr('data-product_upc_code');
        var product_code = $(this).attr('data-product_code');
        var product_price = $(this).attr('data-product_price');
        //  alert(product_size);
        var product_color = $(this).parent().parent().children().find('.color-input').val();
        var quantity = $(this).parent().parent().parent().children().find('.quantity').val();
        if (quantity != '' && product_color != 'Select Color') {

            $.ajax({
                type: "POST",
                async: 'false',
                url: baseurl + "add-cart-item",
                // dataType: "html",
                data: {"product_id": product_id, "category_id": category_id, "product_color": product_color, "product_quantity": quantity},
                success: function (msg) {
                    $('#itemQuantity').text(msg + ' Item');
                    $('#successMsg').show().delay(5000).fadeOut();
                    $('html,body').animate({scrollTop: $('#scrollToTop').offset().top}, 'slow');
                    $(this).parent().parent().children().find('.qty-input').val('');
                }
            })
        }
        else {
            alert("Please Check Fields");
        }
    });
  $("body").delegate(".checkbox", "click", function () {
  
        var checkedValue = $('#product_id:checked').val();
	alert(checkedValue);
	
     $.ajax({
                type: "POST",
                async: 'false',
                url: baseurl + "add-compare-item",
                // dataType: "html",
                data: {"product_id": checkedValue,},
                success: function (msg) {
                
                    alert("product added to comparison list");
                  location.reload();
                }
            })
        
    
     });
   


  
//
//    alert(arr);
////    
// if(arr){
//      
    $("body").delegate(".increment_qty", "click", function () {
        var oldVal = $(this).parent().find(".quantity").val();
        // alert(oldVal);die;
        if (parseInt(oldVal) >= 1) {
            var newVal = parseInt(oldVal) + 1;
            $(this).parent().find(".quantity").val(newVal);
        }
    });
    $("body").delegate(".decrement_qty", "click", function () {
        var oldVal = $(this).parent().find(".quantity").val();
        if (parseInt(oldVal) >= 2) {
            var newVal = parseInt(oldVal) - 1;
            $(this).parent().find(".quantity").val(newVal);
        }
    });
</script>