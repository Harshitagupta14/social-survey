<script type="text/javascript">    function getRecord(href) {
        var dataurl = '<?= $dataURL ?>';
        var posturl;
        if (href) {
            var posturl = href;
        } else {
            var posturl = '<?= site_url() ?>' + dataurl;
        }
        $.ajax({type: "GET", url: posturl, beforeSend: function() {
            }, success: function(html) {
                if ("div") {
                    $("div#my-list").html('');
                    $("div#my-list").append(html);
                }
                if ("article") {
                    $("article#my-list").html('');
                    $("article#my-list").append(html);
                }
            }});
        return false;
    }
    $(document).ready(function() {
        getRecord(null);
        $('body').on('click', '.left_paging a', function() {
            var href = $(this).attr('href');
            getRecord(href, null);
            return false;
        });
    });</script>