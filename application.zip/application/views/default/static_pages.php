<section class="content_section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 cat_bar">
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <li class="active"><?= $breadcrumb ?></li>
                </ol>
                <div class="grid_bar">
                    <h4><?= $page_detail->page_heading ?></h4>
                </div>
                <?= $page_detail->page_content ?>
            </div>
        </div>
    </div>
</div>
</section>
