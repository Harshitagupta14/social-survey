<div class="mid">
    <div class="container" id="scrollToTop">
        <div class="row">
            <?php echo $this->load->view($this->config->item('template') . '/categoryList') ?>
            <!-- right bar -->
            <div class="col-sm-12 col-md-9 cat_bar">
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <?= $breadcrumb ?>
                </ol>
                <div class="alert alert-success" id="successMsg" style="display:none;">
                    <a href="#" class="close" data-dismiss="alert">&times;</a>
                    <strong>Success! </strong> Product Has Been Added To Cart Successfully.
                </div>
                <div class="grid_bar">
                    <h4><?php echo (!empty($category_detail))?$category_detail->category_name .' Products':'' ?></h4>
<!--                    <div class="pull-right">
                        <a href="#">List View <i class="fa fa-list"></i></a>
                        <a href="#">Grid View <i class="fa fa-th"></i></a>
                    </div>-->
                    <div class="clearfix"></div>
                </div>
                <div id="my-list">
                    <?php
if (isset($product_data) and $product_data != '') {
    foreach ($product_data as $product) {
        $product_featured_image = $this->product->get_product_featured_image($product['product_id']);
        ?>
        <div class="list_bar">
            <div class="pro_img">
                <?php
                $file_path = FCPATH . "assets/uploads/product_images/" . $product_featured_image->image_name;
                if ($product_featured_image->image_name != '' && file_exists($file_path)) {
                    ?>
                    <a class="fancybox" href="<?= $this->config->item('uploads') ?>product_images/<?= $product_featured_image->image_name ?>">
                        <img class="img-responsive" src="<?= $this->config->item('uploads') ?>product_images/<?= $product_featured_image->image_name ?>" alt="<?= $product['product_name'] ?>" >
                    </a>
                <?php } else { ?>
                    <img class="img-responsive" src="<?= site_url('assets/uploads/product_images/image_not_available.jpg') ?>">
                <?php } ?>       
            </div>
            <div class="list_detail">
                <a href="<?= site_url('product/' . $product['slug']) ?>" class="viewdetail">View Detail</a>
                <h2><?= $product['product_title'] ?></h2>
                <div>
                    <span class="code_no">UPC CODE :</span>
                    <span class="code_no"><?= $product['product_upc_code'] ?></span>
                </div>
                <br/>
                <div>
                    <span class="code_no">Product Code :</span>
                    <span class="code_no"><?= $product['product_code'] ?></span>
                </div>
                <div class="color_bar"> 
                    <div class="color">
                        <label>color:</label>
                        <select name="product_color">
                            <option>Select Color</option>
                            <?php
                            $product_colors = $product['product_color'];
                            $product_colors = explode(',', $product_colors);
                            foreach ($product_colors as $product_color) {
                                ?>
                                <option value="<?= $product_color ?>"><?= $product_color ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <h3>Product Description :</h3>
                <?= character_limiter($product['product_small_description'], 100); ?>  
            </div>
            <div class="clearfix"></div>
        </div>
    <?php
    }
} else {
    ?>
    <p>No Products Found</p>
<?php } ?>
                </div>               				
                
            </div>        
        </div>
    </div>
</div>	
<script>
    $('body').delegate('.addToCart', 'click', function () {
        var product_id = $(this).attr('data-product_id');
        var category_id = $(this).attr('data-category_id');
        var product_title = $(this).attr('data-product_title');
        var product_description = $(this).attr('data-product_description');
        var product_upc_code = $(this).attr('data-product_upc_code');
        var product_code = $(this).attr('data-product_code');
        var product_price = $(this).attr('data-product_price');
        //  alert(product_size);
        var product_color = $(this).parent().parent().children().find('.color-input').val();
        var quantity = $(this).parent().parent().parent().children().find('.quantity').val();
        if (quantity != '' && product_color != 'Select Color') {

            $.ajax({
                type: "POST",
                async: 'false',
                url: baseurl + "add-cart-item",
                // dataType: "html",
                data: {"product_id": product_id, "category_id": category_id, "product_color": product_color, "product_quantity": quantity},
                success: function (msg) {
                    $('#itemQuantity').text(msg + ' Item');
                    $('#successMsg').show().delay(5000).fadeOut();
                    $('html,body').animate({scrollTop: $('#scrollToTop').offset().top}, 'slow');
                    $(this).parent().parent().children().find('.qty-input').val('');
                }
            })
        }
        else {
            alert("Please Check Fields");
        }
    });
    $("body").delegate(".increment_qty", "click", function () {
        var oldVal = $(this).parent().find(".quantity").val();
        // alert(oldVal);die;
        if (parseInt(oldVal) >= 1) {
            var newVal = parseInt(oldVal) + 1;
            $(this).parent().find(".quantity").val(newVal);
        }
    });
    $("body").delegate(".decrement_qty", "click", function () {
        var oldVal = $(this).parent().find(".quantity").val();
        if (parseInt(oldVal) >= 2) {
            var newVal = parseInt(oldVal) - 1;
            $(this).parent().find(".quantity").val(newVal);
        }
    });
</script>