<div class="footer" id="footer">
    <div class="container">
        <ul class=" pull-left navbar-link footer-nav">
            <li><a href="index.html"> Home </a> <a href="about-us.html"> About us </a> <a href="terms-conditions.html"> Terms and
                    Conditions </a> <a href="#"> Privacy Policy </a> <a href="contact.html"> Contact us </a> <a href="faq.html"> FAQ </a>
        </ul>
        <ul class=" pull-right navbar-link footer-nav">
            <li> &copy; 2015 Polson</li>
        </ul>
    </div>
</div>

</div>


<script src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
crossorigin="anonymous"></script>
<script src="<?= $this->config->item('frontassets') ?>bootstrap/js/bootstrap.min.js"></script>

<script src="<?= $this->config->item('frontassets') ?>js/owl.carousel.min.js"></script>

<script src="<?= $this->config->item('frontassets') ?>js/jquery.matchHeight-min.js"></script>

<script src="<?= $this->config->item('frontassets') ?>js/hideMaxListItem.js"></script>

<script src="<?= $this->config->item('frontassets') ?>plugins/jquery.fs.scroller/jquery.fs.scroller.js"></script>
<script src="<?= $this->config->item('frontassets') ?>plugins/jquery.fs.selecter/jquery.fs.selecter.js"></script>

<script src="<?= $this->config->item('frontassets') ?>js/script.js"></script>
<script>


</script>

<script type="text/javascript" src="<?= $this->config->item('frontassets') ?>plugins/autocomplete/jquery.mockjax.js"></script>
<script type="text/javascript" src="<?= $this->config->item('frontassets') ?>plugins/autocomplete/jquery.autocomplete.js"></script>
<script type="text/javascript" src="<?= $this->config->item('frontassets') ?>plugins/autocomplete/usastates.js"></script>
<script type="text/javascript" src="<?= $this->config->item('frontassets') ?>plugins/autocomplete/autocomplete-demo.js"></script>
</body>

<!-- Mirrored from templatecycle.com/demo/bootclassified-v1.5/dist/index-v-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 12 Oct 2016 17:10:33 GMT -->
</html>
