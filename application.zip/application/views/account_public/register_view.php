<?php $this->load->view($this->config->item('public_folder_name') . '/header'); ?>
<style>
.icon-txt {
    color: #fff;
    font-size: 18px;
    margin: 20px 0;
    text-align: center;
    text-transform: uppercase;
    width: 100%;
}
.icon-outer {
    background-color: rgba(255, 255, 255, 0.6);
    border-radius: 50%;
    height: 200px;
    margin: 0 auto;
    padding: 30px;
    text-align: center;
    width: 200px;
}
a:focus {
    text-decoration: none;
}

a:active, a:hover {
    outline: 0 none;
}
a {
    color: #000;
    text-decoration: none;
}

a {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
}
.icon-c {
    background: #ff7201 none repeat scroll 0 0;
    border: 8px solid #fff;
    border-radius: 50%;
    height: 140px;
    padding: 20px;
    width: 140px;
}


</style>
<div class="main-container" style="background:rgb(20, 144, 120">
    <div class="container">
        <div class="row">
            <div class="col-md-8 page-content">
                <div class="mid">
                <div class="container">
					<div class="row"><div class="col-md-12"><div class="icon-txt">Register your account as</div></div></div>
                    <div class="row" style="margin-top:100px;"><div class="col-md-2"></div>
                    <div class="col-md-8" >
                        <div class="col-md-6 col-sm-6">
                            <a href="<?php echo base_url(); ?>registration-customer">
                            	<div class="icon-txt">Customer</div>
                                <div class="icon-outer">
                                    <div class="icon-c">
                                        <img src="<?php echo base_url(); ?>assets/frontend/images/icon1.png">
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <a href="<?php echo base_url(); ?>registration-service-provider">
                            	<div class="icon-txt">Service Provider</div>
                                <div class="icon-outer">
                                    <div class="icon-c">
                                        <img src="<?php echo base_url(); ?>assets/frontend/images/icon2.png">
                                    </div>
                                    
                                </div>
                                
                            </a>
                        </div>
                    </div>
                    <div class="col-md-2"></div>
					</div>
                </div>
            </div>
            </div>

           
        </div>

    </div>

</div>


<?php $this->load->view($this->config->item('public_folder_name') . '/footer'); ?>