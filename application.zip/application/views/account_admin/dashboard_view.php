
<?php $this->load->view($this->config->item('admin_login_folder') . '/header'); ?> 
<ul class="breadcrumb">
    <li><a href="<?= site_url('admin/dashboard') ?>">Home</a></li>                    
    <li class="active">Dashboard</li>
</ul>             
<div class="page-content-wrap">

    <div class="row">
   <?php if (!empty($message)) { ?>
            <?php echo $message; ?>
        <?php } ?>
        
                        <div class="col-md-3">  
                            <div class="widget widget-danger widget-padding-sm">
                                <div class="widget-big-int plugin-clock">00:00</div>                            
                                <div class="widget-subtitle plugin-date">Loading...</div>                                            
                            </div>  
                        </div>
    </div>
</div>
<!-- END PAGE CONTENT WRAPPER -->                                

<?php $this->load->view($this->config->item('admin_login_folder') . '/footer'); ?> 
