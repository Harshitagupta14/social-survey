<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php
            $current_url = current_url();
            $meta_tags = $this->common_model->getMetaTags($current_url);
            if ($meta_tags) {
                $METATITLE = $meta_tags['metatag_title'];
                $METAKEYWORDS = $meta_tags['metatag_keyword'];
                $METADESCRIPTION = $meta_tags['metatag_description'];
            }
            if ($METATITLE) {
                echo $METATITLE;
            } else {
                echo $this->config->item('site_title');
            }
            ?>
        </title>
        <?php if ($METAKEYWORDS) { ?>
            <meta name="keywords" content="<?php echo $METAKEYWORDS ?>" />
        <?php } else { ?>
            <meta name="keywords" content="<?php echo $this->config->item('meta_keywords'); ?>" />
        <?php } ?>
        <?php if ($METADESCRIPTION) { ?>
            <meta name="description" content="<?php echo $METADESCRIPTION ?>" />
        <?php } else { ?>
            <meta name="description" content="<?php echo $this->config->item('meta_description'); ?>" />
        <?php } ?>

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?= $this->config->item('frontassets') ?>ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?= $this->config->item('frontassets') ?>ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?= $this->config->item('frontassets') ?>ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="<?= $this->config->item('frontassets') ?>ico/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="<?= $this->config->item('frontassets') ?>ico/favicon.png">
        <title>BOOTCLASIFIED - Responsive Classified Theme</title>

        <link href="<?= $this->config->item('frontassets') ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <link href="<?= $this->config->item('frontassets') ?>css/style.css" rel="stylesheet">

        <link href="<?= $this->config->item('frontassets') ?>css/owl.carousel.css" rel="stylesheet">
        <link href="<?= $this->config->item('frontassets') ?>css/owl.theme.css" rel="stylesheet">


        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
            <![endif]-->

        <script>
            paceOptions = {
                elements: true
            };
        </script>
        <script src="<?= $this->config->item('frontassets') ?>js/pace.min.js"></script>
    </head>
    <body>
        <div id="wrapper">
            <div class="header">
                <nav class="navbar   navbar-site navbar-default" role="navigation">
                    <div class="container">
                        <div class="navbar-header">
                            <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
                                <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span></button>
                            <a href="index.html" class="navbar-brand logo logo-title">

                                <span class="logo-icon"><i class="icon icon-search-1 ln-shadow-logo shape-0"></i> </span>
                                POLSON</a></div>
                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <?php
                                if ($this->flexi_auth->is_logged_in()) {
                                    $user_data = $this->flexi_auth->get_user_by_identity_row_array();
                                    ?>
                                    <li><a href="<?= site_url('account/logout') ?>">Signout <i class="glyphicon glyphicon-off"></i> </a></li>
                                    <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                            <span><?= $user_data['uacc_email']; ?></span> <i class="icon-user fa"></i> <i class=" icon-down-open-big fa"></i></a>
                                        <ul class="dropdown-menu user-menu">
                                            <li class="active"><a href="<?= site_url('account/dashboard') ?>" ><i class="icon-home"></i> Account
                                                </a></li>
                                        </ul>
                                    </li>
                                    <li class="postadd"><a class="btn btn-block   btn-border btn-post btn-danger" href="post-ads.html">Post Free Add</a></li>

                                <?php } else { ?>
                                    <li><a href="<?= site_url('account/login') ?>">Login</a></li>
                                    <li><a href="<?php echo site_url('quick-registration'); ?>">Signup</a></li>
                                <?php } ?>
                            </ul>

                        </div>

                    </div>

                </nav>
            </div>