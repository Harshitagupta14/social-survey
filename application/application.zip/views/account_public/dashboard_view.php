<?php $this->load->view($this->config->item('public_login_folder') . '/header'); ?>

<div class="main-container">
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="<?= site_url($this->config->item('public_login_url') . '/dashboard') ?>">Dashboard</a></li>
            <li class="active">Profile View</li>
        </ol>
        <?php if (!empty($message)) { ?>
            <div id="message">
                <?php echo $message; ?>
            </div
        <?php } ?>

        <div class="row">
            <div class="col-sm-3 page-sidebar">
                <aside>
                    <div class="inner-box">
                        <div class="user-panel-sidebar">
                            <div class="collapse-box">
                                <h5 class="collapse-title no-border"> My Account <a href="#MyClassified" data-toggle="collapse" class="pull-right"><i class="fa fa-angle-down"></i></a></h5>
                                <div class="panel-collapse collapse in" id="MyClassified">
                                    <ul class="acc-list">

                                        <li class="active"><a href="<?= site_url($this->config->item('public_login_url') . '/dashboard') ?>"> <i class="icon-home"></i> Dashboard</a></li>
                                        <li><a href="<?= site_url($this->config->item('public_login_url') . '/update-account') ?>">Update Profile</a></li>
                                        <li><a href="<?= site_url($this->config->item('public_login_url') . '/order-history') ?>">My Order History</a></li>
                                        <li><a href="<?= site_url($this->config->item('public_login_url') . '/change-password') ?>">Change Password</a></li>
                                        <li><a href="<?= site_url($this->config->item('public_login_url') . '/update-email') ?>">Change Email</a></li>
                                        <li><a href="<?= site_url($this->config->item('public_login_url') . '/logout') ?>">Logout</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </aside>
            </div>

            <div class="col-sm-9 page-content">
                <div class="inner-box">
                    <div class="row">
                        <div class="col-md-5 col-xs-4 col-xxs-12">
                            <h3 class="no-padding text-center-480 useradmin"><a href="#"><img class="userImg" src="<?= $this->config->item('frontassets') ?>images/user.jpg" alt="user"> <?php echo set_value('update_first_name', $user['upro_first_name']); ?> <?php echo set_value('update_last_name', $user['upro_last_name']); ?>
                                </a></h3>
                        </div>
                        <div class="col-md-7 col-xs-8 col-xxs-12">
                            <div class="header-data text-center-xs">

                                <div class="hdata">
                                    <div class="mcol-left">

                                        <i class="fa fa-eye ln-shadow"></i></div>
                                    <div class="mcol-right">

                                        <p><a href="#">7000</a> <em>visits</em></p>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>

                                <div class="hdata">
                                    <div class="mcol-left">

                                        <i class="icon-th-thumb ln-shadow"></i></div>
                                    <div class="mcol-right">

                                        <p><a href="#">12</a><em>Ads</em></p>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>

                                <div class="hdata">
                                    <div class="mcol-left">

                                        <i class="fa fa-user ln-shadow"></i></div>
                                    <div class="mcol-right">

                                        <p><a href="#">18</a> <em>Favorites </em></p>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="inner-box">
                    <form class="form-horizontal">
                        <fieldset>
                            <legend>Personal Information Edit</legend>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">First Name:</label>
                                <div class="col-sm-9">
                                    <p class="help-block"><?php echo set_value('update_first_name', $user['upro_first_name']); ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Last Name:</label>
                                <div class="col-sm-9">
                                    <p class="help-block"><?php echo set_value('update_last_name', $user['upro_last_name']); ?></p>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Contact Details</legend>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Phone Number:</label>
                                <div class="col-sm-9">
                                    <p class="help-block"><?php echo set_value('update_phone_number', $user['upro_phone']); ?></p>
                                </div>
                            </div>

                        </fieldset>
                        <fieldset>
                            <legend>Login Details</legend>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Email:</label>
                                <div class="col-sm-9">
                                    <p class="help-block"><?php echo set_value('update_email', $user[$this->flexi_auth->db_column('user_acc', 'email')]); ?></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Username:</label>
                                <div class="col-sm-9">
                                    <p class="help-block"><?php echo set_value('update_username', $user[$this->flexi_auth->db_column('user_acc', 'username')]); ?></p>
                                </div>
                            </div>
                        </fieldset>
                    </form>

                </div>
            </div>

        </div>

    </div>

    <?php $this->load->view($this->config->item('public_login_folder') . '/footer'); ?>
