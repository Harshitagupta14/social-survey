<?php $this->load->view($this->config->item('public_login_folder') . '/header'); ?>

<div class="main-container">
    <div class="container">
        <?php if (!empty($message)) { ?>
            <?php echo $message; ?>
        <?php } ?>
        <ol class="breadcrumb">
            <li><a href="<?= site_url() ?>">Home</a></li>
            <li class="active">Login</li>
        </ol>
        <div class="row">
            <div class="col-sm-5 login-box">
                <div class="panel panel-default">
                    <div class="panel-intro text-center">
                        <h2 class="logo-title">

                            <span class="logo-icon"><i class="icon icon-search-1 ln-shadow-logo shape-0"></i> </span>POLSON <span>LOGIN </span>
                        </h2>
                    </div>
                    <div class="panel-body">
                        <form action="" class=" " method="post">
                            <div class="form-group">
                                <label for="sender-email" class="control-label">Username:</label>
                                <div class="input-icon"><i class="icon-user fa"></i>
                                    <input id="sender-email" type="text" name="login_identity" class="form-control" placeholder="Username Or Email-Id">
                                    <span class="help-block" style="color: red;"><?= strip_tags(form_error('login_identity')) ?></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="user-pass" class="control-label">Password:</label>
                                <div class="input-icon"><i class="icon-lock fa"></i>
                                    <input type="password" name="login_password" class="form-control " placeholder="Password" id="user-pass">
                                    <span class="help-block" style="color: red;"><?= strip_tags(form_error('login_password')) ?></span>
                                </div>
                            </div>
                            <?php
                            if (isset($captcha)) {
                                echo "<div class=\"form-group\">";
                                echo " <label class=\"control-label\">Captcha</label>";
                                echo $captcha . ' = <input type="text" id="captcha" name="login_captcha" class="form-control " placeholder="Captcha Question"/>' . "\n";
                                echo "</div>";
                            }
                            ?>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary  btn-block" value="Submit" name="login_user">
                                <input type="hidden" value="save" name="form_submit">
                            </div>
                        </form>
                    </div>
                    <div class="panel-footer">
                        <div class="checkbox pull-left">
                           <!-- <label> <input type="checkbox" value="1" name="remember" id="remember"> Keep me logged
                                in</label> -->
                        </div>
                        <p class="text-center pull-right"><a  href="<?= site_url('forgot-password') ?>"> Lost your password? </a>
                        </p>
                        <div style=" clear:both"></div>
                    </div>
                </div>
                <div class="login-box-btm text-center">
                    <p> Don't have an account? <br>
                        <a href="<?= site_url('account') ?>"><strong>Sign Up !</strong> </a></p>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $this->load->view($this->config->item('public_folder_name') . '/footer'); ?>
