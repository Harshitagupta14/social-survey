<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- META SECTION -->
        <title><?= $this->config->item('sitename'); ?>| Admin Panel</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="favicon.ico" type="image/x-icon" />
        <!-- END META SECTION -->   
        <link rel="stylesheet" type="text/css" id="theme" href="<?= $this->config->item('adminassets') ?>css/theme-default.css"/>
        <link rel="stylesheet" type="text/css" id="theme" href="<?= $this->config->item('adminassets') ?>css/dropzone/dropzone.css"/>
        <link rel="stylesheet" type="text/css" id="theme" href="<?= $this->config->item('adminassets') ?>css/blueimp/blueimp-gallery.min.css"/>
		<link rel="stylesheet" type="text/css" id="theme" href="<?= $this->config->item('adminassets') ?>css/jquery.dataTables.css"/>
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/bootstrap/bootstrap.min.js"></script>      
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/bootstrap/bootstrap-select.js"></script>      
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/bootstrap/bootstrap-file-input.js"></script>      
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins/owl/owl.carousel.min.js"></script>     
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/plugins.js"></script>      
        <script type="text/javascript" src="<?= $this->config->item('adminassets'); ?>js/actions.js"></script>  
        <script>
            var baseurl = '<?= base_url() ?>';
        </script>
    </head>
    <body>
        <div class="page-container page-navigation-top page-navigation-top-custom">
            <div class="page-content">
                <ul class="x-navigation x-navigation-horizontal">
                    <li class="xn-navigation-control"> <a href="#" class="x-navigation-control"></a> </li>
                    <li><a href="<?= base_url() ?>admin/dashboard"><span class="fa fa-desktop"></span><span class="xn-text">Dashboard</span></a></li>
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-file-image-o"></span> <span class="xn-text">Banner</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/banner-list"> Manage Banner</a></li>
                            <li><a href="<?= base_url() ?>admin/banner-add"> Add Banner</a></li>                        
                        </ul>
                    </li> 
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-file"></span> <span class="xn-text">Blog</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/blog-list"> Manage Blog</a></li>
                            <li><a href="<?= base_url() ?>admin/blog-add"> Add Blog</a></li>                        
                            <li><a href="<?= base_url() ?>admin/blog-category-list"> Manage Blog Category</a></li>
                            <li><a href="<?= base_url() ?>admin/blog-category-add"> Add Blog Category</a></li>    
                        </ul>
                    </li>
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-file-image-o"></span> <span class="xn-text">Product</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/product-list"> Manage Product</a></li>
                            <li><a href="<?= base_url() ?>admin/product-add"> Add Product </a></li>    
                            <li><a href="<?= base_url() ?>admin/product_types-list"> Manage Product Types</a></li>
                            <li><a href="<?= base_url() ?>admin/product_types-add"> Add Product Types</a></li>     
                        </ul>
                    </li>
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-file-image-o"></span> <span class="xn-text"> Category</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/category-list"> Manage Category</a></li>
                            <li><a href="<?= base_url() ?>admin/category-add"> Add Category</a></li>                        
                        </ul>
                    </li>
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Contact Us</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/enquiry-list">Enquiry List</a></li>                          
                        </ul>
                    </li>
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-files-o"></span> <span class="xn-text">Orders </span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/order-list">Order List</a></li>                          
                        </ul>
                    </li>
                    <!--                     <li class="xn-openable">
                                               <a href="#"><span class="fa fa-file-image-o"></span> <span class="xn-text"> Links</span></a>
                                                <ul>
                                               <li><a href="<?= base_url() ?>admin/nav_menu-list"> Manage Nav Links</a></li>
                                                <li><a href="<?= base_url() ?>admin/nav_menu-add"> Add Nav Links</a></li>   
                                                  </ul>
                                        </li> -->
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-file-image-o"></span> <span class="xn-text">Location</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/country-list"> Manage Country</a></li>
                            <li><a href="<?= base_url() ?>admin/country-add"> Add Country</a></li>    
                            <li><a href="<?= base_url() ?>admin/province-list"> Manage Province</a></li>
                            <li><a href="<?= base_url() ?>admin/province-add"> Add Province</a></li>     
                        </ul>
                    </li>
                    
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-file-image-o"></span> <span class="xn-text">Post</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/post-list"> Manage Post</a></li>
                            <li><a href="<?= base_url() ?>admin/post-add"> Add Post</a></li>      
                        </ul>
                    </li>
                    
                    <li class="xn-openable">
                        <a href="#"><span class="fa fa-file-image-o"></span> <span class="xn-text">Others</span></a>
                        <ul>
                            <li><a href="<?= base_url() ?>admin/metatag-list"> Manage Metatag</a></li>
                            <li><a href="<?= base_url() ?>admin/metatag-add"> Add Metatag</a></li>   
                            <li><a href="<?= base_url() ?>admin/page-list"> Manage Page</a></li>
                            <li><a href="<?= base_url() ?>admin/page-add"> Add Page</a></li>  
                            <li><a href="<?= base_url() ?>admin/website-links">Website Settings</a></li> 
                        </ul>
                    </li>
                    <!-- POWER OFF -->
                    <li class="xn-icon-button pull-right last"> <a href="#"><span class="fa fa-power-off"></span></a>
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="javascript:" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span> Sign Out</a></li>
                        </ul>
                    </li>             
                </ul>
                <!-- END X-NAVIGATION VERTICAL -->