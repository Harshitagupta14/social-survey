<ol class="breadcrumb">
    <li><a href="<?= site_url() ?>">Home</a> </li>
    <li class="active"><?= $breadcrumb ?></li>
</ol>