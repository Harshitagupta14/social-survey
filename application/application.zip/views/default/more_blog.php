<script>
    $(document).ready(function () {
        $('#paging').html('<?= $paging ?>');
    });
</script>

