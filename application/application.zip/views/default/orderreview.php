
<section class="content_section">
    <div class="container">
        <div class="alert alert-success" id="successMsg" style="display:none;">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Success! </strong> Quantity Updated Successfully.
        </div>
        <?php if ($this->session->flashdata('ProductSuccess')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('ProductSuccess') ?></div>
        <?php } ?>

        <ul class="steps">
            <li>Shopping Cart</li>
            <li>Shipping</li>
            <li class="current">Order Review</li>
            <li>Order Complete</li>
        </ul>

        <div class="oreder-review col-sm-12">
            <form action="order-confirmation" class="form-horizontal" method="post" enctype="multipart/form-data">
                <div class="clearfix"></div>
                <div class="col-sm-8">
                    <h3>Cart Details</h3>
                    <hr>
                </div>
                <div class="col-sm-4">
                    <h3>Shipping Details</h3>
                    <hr>
                </div>
                <div class="col-sm-8"><table cellspacing="0" cellpadding="0" border="0" class="table table-bordered table-striped cart_table">
                        <tr>
                            <th>Product</th>        
                            <th width="100">Code</th>
                            <th width="100">Price</th>
                            <th width="100">Quantity</th>
                            <th width="100">Total</th>
                        </tr>
                        <?php
                        foreach ($cart_items_data as $cart_item) {
                          
                           
                            ?>
                            <tr>
                                <td><?=$cart_item['product_title']?></td>
                                <td><?=$cart_item['product_code']?></td>
                                <td><?=$cart_item['unit_product_price']?></td>
                                <td><?=$cart_item['product_quantity']?></td>
                                <td align="right"><?= $this->config->item('site_currency'); ?> <?=$cart_item['total_product_price']?></td>
                            </tr>
                        <?php } ?>
                            <?php  $cart_detail = $this->cart->getCartDetail(); ?>
                            <tr>
                            <td colspan="4"  align="right">Sub-Total:</td>
                            <td   align="right"><?= $this->config->item('site_currency'); ?> <?= $cart_detail['sub_total']; ?></td>
                            </tr>
                            <tr>
                            <td colspan="4" align="right"><?php if ($cart_detail['coupon_per'] != 0.00) { ?>(Discount Percentage: <?= $cart_detail['coupon_per']; ?>% )<?php } ?> Discount:</td>
                            <td   align="right"><?= $this->config->item('site_currency'); ?> <?= $cart_detail['total_discount']; ?></td>
                            </tr>
                            <?php if ($cart_detail['gst_per'] != 0.00) { ?>
                            <tr>
                            <td colspan="4" id="gst_tax_perc" align="right">GST Amount (<?php echo $cart_detail['gst_per'] ?> %) :</td>
                            <td align="right" id="gst_tax_value"><?= $this->config->item('site_currency'); ?> <?php echo $cart_detail['gst'] ?></td>
                            </tr>
                            <?php }?>
                            <tr>
                             <td colspan="4" align="right"><strong>Total Payable Amount:</strong></td>
                            <td   align="right" id="total_value"><?= $this->config->item('site_currency'); ?> <?php echo $cart_detail['total_cart_price'] ?></td>
                            </tr>
                    </table></div>

                <div class="col-sm-4">



                    <dl class="dl-horizontal">
                        <dt>First Name:</dt>
                        <dd>
                            <div class="form-control-static"><?php echo (isset($order_data['first_name'])) ? $order_data['first_name'] : '-'; ?></div>
                        </dd>
                        <dt>Last Name:</dt>
                        <dd>
                            <div class="form-control-static"><?php echo (isset($order_data['last_name'])) ? $order_data['last_name'] : '-'; ?></div>
                        </dd>
                        <dt>Address:</dt>
                        <dd>
                            <div class="form-control-static"><?php echo $order_data['address']?></div>
                        </dd>
                        <dt>Contact Number:</dt>
                        <dd>
                            <div class="form-control-static"><?php echo (isset($order_data['contact_no'])) ? $order_data['contact_no'] : '-'; ?></div>
                        </dd>
                        <dt>City:</dt>
                        <dd>
                            <div class="form-control-static"><?php echo (isset($order_data['city'])) ? $order_data['city'] : '-'; ?></div>
                        </dd>
                        <dt>Province:</dt>
                        <dd>
                            <div class="form-control-static"><?php echo (isset($order_data['province_name'])) ? $order_data['province_name'] : '-'; ?></div>
                        </dd>
                        <dt>Postal Code</dt>
                        <dd>
                            <div class="form-control-static"><?php echo (isset($order_data['postal_code'])) ? $order_data['postal_code'] : '-'; ?></div>
                        </dd>
                    </dl>
                </div>
                <div class="clearfix"></div>          
                <input type="submit" name="submit" class="btn btn-success" value="Confirm Order" />
                <input type="hidden" name="form_submit" value="save" />
                <input type="hidden" name="orderCompletion" class="cart-btn" value="save" />

                <form action="cancel-order" class="form-inline" method="post" enctype="multipart/form-data">
                    <input type="submit" name="submit" class="btn btn-success" value="Cancel Order" />
                    <input type="hidden" name="form_submit" value="save" />
                    <input type="hidden" name="orderCompletion" class="cart-btn" value="save" />
                </form>
            </form>
        </div>
</section>

<script type="text/javascript">
    $('body').delegate('.updateCart', 'click', function() {
        var product_id = $(this).attr('data-product_id');
        var product_price = $(this).attr('data-product_price');
        var quantity = $(this).parent().parent().children().find('.qty-input').val();
        if (quantity != '') {

            $.ajax({
                type: "POST",
                async: 'false',
                url: "<?php echo site_url('updatecart') ?>",
                // dataType: "html",
                data: {"product_id": product_id, "product_quantity": quantity, "product_price": product_price},
                success: function(msg) {
                    // location.reload(); 
                    $('#itemQuantity').text(msg + ' Item');
                    $('#successMsg').show().delay(10000).fadeOut();
                }
            })
        } else {
            alert("Please Update Quantity Of Items");
        }
    });
</script>