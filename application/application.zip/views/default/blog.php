<section class="content_section">
    <div class="container">
       
        <div class="row">
           
            <?php $this->load->view($this->config->item('template') . '/blog-rightbar'); ?>
            <div class="col-sm-9">
                  <?php if ($this->session->flashdata('BlogSuccessMessage')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('BlogSuccessMessage') ?></div>
        <?php } ?>
        <?php if ($this->session->flashdata('BlogErrorMessage')) { ?>  
            <div class="alert alert-danger"> <?= $this->session->flashdata('BlogErrorMessage') ?></div>
        <?php } ?>
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <li class="active">Blog</li>
                </ol>
                <div class="grid_bar">
                    <h4>Our Blogs</h4>
                </div>
                <?php foreach ($blog_data as $blog) { ?>
                    <article class="blog_row">
                        <?php
                        if($blog['show_image'] == 'yes'){
                        $file_path = FCPATH . "assets/uploads/blog_images/" . $blog['blog_image'];
                        if ($blog['blog_image'] != '' && file_exists($file_path)) {
                            ?>
                            <a class="pull-left" href="#">
                                <img src="<?= site_url('assets/uploads/blog_images/' . $blog['blog_image']) ?>" alt="<?= $blog_detail->blog_title ?>" >
                            </a>
                        <?php }} ?>
                        <div class="blog-desc">
                            <h4><a href="<?= site_url('blog/' . $blog['slug']) ?>"><?= $blog['blog_title']; ?></a></h4>
                            <h6>Posted on <i class="fa fa-calendar"></i> <?= date('d M Y', $blog['add_time']); ?> by <i class="fa fa-user"></i> Admin</h6>
                            <p><?= $blog['blog_description']; ?>
                                <a href="<?= site_url('blog/' . $blog['slug']) ?>" class="btn btn-success btn-radius pull-right">Read More</a>
                        </div>
                    </article>
                <?php } ?> 
            </div>
        </div>
    </div>
</section>
