<section class="content_section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 cat_bar">
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <li class="active">Contact Us</li>
                </ol>
                <div class="grid_bar">
                    <h4>Contact Us</h4>
                </div>
                <div class="row">
                    <div class="contact-form col-md-7">
                        <?php if ($this->session->userdata('contactSuccessMessage')) { ?>  
                            <div class="alert alert-success"> <?= $this->session->userdata('contactSuccessMessage') ?></div>
                        <?php }$this->session->unset_userdata('contactSuccessMessage'); if ($this->session->userdata('contactErrorMessage')) { ?>  
                            <div class="alert alert-danger"> <?= $this->session->userdata('contactErrorMessage') ?></div>
                        <?php }$this->session->unset_userdata('contactErrorMessage'); ?>
                        <form method="post">
                            <div class="form-group"><label for="full_name" class="nameLabel">Full Name</label>
                                <input class="form-control" id="name" type="text" name="full_name" placeholder="Enter your name..." required>
                            </div>
                            <div class="form-group"><label for="email_id" class="emailLabel">Email</label>
                                <input class="form-control" id="email" type="email" name="email_id" placeholder="Enter your email..." required>
                            </div>
                            <div class="form-group"><label for="subject">Subject</label>
                                <input class="form-control" id="subject" type="text" name="subject" placeholder="Your subject..." required>
                            </div>
                            <div class="form-group"><label for="message" class="messageLabel">Message</label>
                                <textarea class="form-control" id="message" name="message" placeholder="Your message..." rows="8" required></textarea>
                            </div>
                            <input type="submit" value="Send" class="btn btn-success btn-radius">
                        </form>
                    </div>
                    <div class="contact-address col-md-5">
                        <h3>We Are Here</h3>
                        <iframe scrolling="no" marginheight="0" marginwidth="0" src="<?= $this->config->item('google_map'); ?>" frameborder="0" class="contactmap"></iframe>
                        <address class="well">
                            <h4><?= $this->config->item('site_title'); ?></h4>
                            <p><i class="fa fa-map-marker"></i> <?= $this->config->item('contact_address'); ?></p>
                            <p><i class="fa fa-phone"></i> : <a href="tel:<?= $this->config->item('contact_no'); ?>"><?= $this->config->item('contact_no'); ?></a><br>
                                <i class="fa fa-envelope"></i> : <?= $this->config->item('site_email'); ?></p>
                        </address>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>