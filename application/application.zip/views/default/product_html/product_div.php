<div class="productList">
    <div role="tabpanel" class="tab-pane  active" id="arrivals">
    <?php
    $i = 1;
    if (isset($product_data) && !empty($product_data))
        foreach ($product_data as $product) {
            $product_featured_image = $this->product->get_product_featured_image($product['product_id']);
            ?>
            <div class="col-xs-6 col-sm-4 col-md-4 full_width">
                <div class="tab_pro">
                    <?php
                    $file_path = FCPATH . "assets/uploads/product_images/" . $product_featured_image->image_name;
                    if ($product_featured_image->image_name != '' && file_exists($file_path)) {
                        ?>
                        <a href="<?= site_url('product/' . $product['slug']) ?>">
                            <img class="img-responsive" src="<?= site_url() . image('uploads/product_images/' . $product_featured_image->image_name, array(250, 250)) ?>">
                        </a>
                    <?php } else { ?>
                        <img class="img-responsive" src="http://www.placehold.it/250x250/EFEFEF/AAAAAA&amp;text=no+image">
                    <?php } ?>
                    <h2><a href="<?= site_url('product/' . $product['slug']) ?>"><?= $product['product_title'] ?></a></h2>
                    <p><?= character_limiter($product['product_small_description'], 200) ?> </p>
                    <a href="<?= site_url('product/' . $product['slug']) ?>" class="view">View Detail</a>
                </div>
            </div>
            <?php if ($i % 3 == 0) { ?>
                <div class="clearfix"></div>
                <?php
            } $i++;
        }
    ?>
</div>
</div>