


<div class="col-sm-3 page-sidebar mobile-filter-sidebar">
    <div class="inner-box">
        <div class="categories-list  list-filter">
            <h5 class="list-title"><strong><a href="#">All Categories</a></strong></h5>
            <div class="collapse-box">
                <?php
                $parent_categories_list = $this->product->get_categories(0);
                foreach ($parent_categories_list as $parent_category) {
                    $sub_categories_list = $this->product->get_categories($parent_category['category_id']);
                    ?>
                    <a href="<?= site_url('category/' . $parent_category['slug']) ?>" > <h5> <?= $parent_category['category_name'] ?></h5></a>

                    <?php
                }
                ?>
            </div>
        </div>
    </div
    <div>
    </div>

