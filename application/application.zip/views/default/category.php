<?php echo $this->load->view($this->config->item('template') . '/search_filter_top') ?>
<div class="main-container">
    <div class="container">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="<?= site_url() ?>" ><i class="icon-home fa"></i></a></li>
                <?= $breadcrumb ?>
            </ol>
        </div>
        <div class="row">
            <?php echo $this->load->view($this->config->item('template') . '/categoryList') ?>
            <div class="col-sm-9 page-content col-thin-left">
                <div class="category-list">


                    <div class="listing-filter">
                        <div class="pull-right col-xs-6 text-right listing-view-action"><span class="list-view active"><i class="  icon-th"></i></span> <span class="compact-view"><i class=" icon-th-list  "></i></span> <span class="grid-view "><i class=" icon-th-large "></i></span></div>
                        <div style="clear:both"></div>
                    </div>


                    <div class="mobile-filter-bar col-lg-12  ">
                        <ul class="list-unstyled list-inline no-margin no-padding">
                            <li class="filter-toggle">
                                <a class="">
                                    <i class="  icon-th-list"></i>
                                    Filters
                                </a>
                            </li>
                            <li>
                                <div class="dropdown">
                                    <a data-toggle="dropdown" class="dropdown-toggle"><i class="caret "></i> Short
                                        by </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#" rel="nofollow">Relevance</a></li>
                                        <li><a href="#" rel="nofollow">Date</a></li>
                                        <li><a href="#" rel="nofollow">Company</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="menu-overly-mask"></div>

                    <div class="adds-wrapper property-list">
                        <?php
                        if (isset($category_data) && !empty($category_data)) { //pr($category_data);die;
                            foreach ($category_data as $category) {
                                ?>

                                <div class="item-list">
                                    <div class="col-sm-3 no-padding photobox">
                                        <div class="add-image"><a class="" href="<?= site_url('category/' . $category->slug) ?>"> <?php
                                                $count_sub_category = $this->common_model->getCountAllFromAnyTable('parent_id', $category->category_id, 'tbl_category', 'active');
                                                $file_path = FCPATH . "assets/uploads/category_images/" . $category->category_image;
                                                if ($category->category_image != '' && file_exists($file_path)) {
                                                    ?>


                                                    <img class="thumbnail no-margin" src="<?= $this->config->item('uploads') ?>category_images/<?= $category->category_image ?>" alt="<?= $category->category_name ?>" >

                                                <?php } else { ?>
                                                    <img class="thumbnail no-margin" src="<?= site_url('assets/uploads/category_images/image_not_available.jpg') ?>">
                                                <?php } ?></a></div>
                                    </div>

                                    <div class="col-sm-6 add-desc-box">
                                        <div class="add-details">
                                            <h5 class="add-title"><a href="property-details.html">
                                                    <?= $category->category_name ?> </a></h5>
                                            <span class="info-row"> <span class="little-info">Services Available: A , B , C ,D</span> </span>
                                            <div class="prop-info-box">
                                                <div class="prop-info">
                                                    <div class="clearfix prop-info-block">
                                                        <span class="title ">2</span>
                                                        <span class="text">Services</span>
                                                    </div>
                                                    <div class="clearfix prop-info-block middle">
                                                        <span class="title">150</span>
                                                        <span class="text">Professionals</span>
                                                    </div>
                                                    <div class="clearfix prop-info-block">
                                                        <span class="title">2</span>
                                                        <span class="text">Cities</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-3 text-right  price-box">
                                        <!--   <a class="btn btn-border-thin  btn-save" title="save ads" data-toggle="tooltip" data-placement="left">
                                               <i class="icon icon-heart"></i>
                                           </a>
                                           <a class="btn btn-border-thin  btn-share ">
                                               <i class="icon icon-export" data-toggle="tooltip" data-placement="left" title="share"></i>
                                           </a> -->
                                        <h3 class="item-price "> <strong>~ &#8377; 99 - &#8377; 2999 </strong></h3>
                                        <div style="clear: both"></div>
                                        <a class="btn btn-success btn-sm bold" href="property-details.html">
                                            Check Services
                                        </a>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        ?>




                    </div>
                </div>
            </div>
        </div>
    </div>
