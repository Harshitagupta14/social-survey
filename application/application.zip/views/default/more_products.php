
<?php
if (isset($product_data) and $product_data != '') {

    foreach ($product_data as $product) {
        $product_featured_image = $this->product->get_product_featured_image($product['product_id']);
        ?>
        <div class="item-list">
            <div class="col-sm-3 no-padding photobox">
                <div class="add-image"><a class="fancybox" href="<?= $this->config->item('uploads') ?>product_images/<?= $product_featured_image->image_name ?>">  <?php
                        $file_path = FCPATH . "assets/uploads/product_images/" . $product_featured_image->image_name;
                        if ($product_featured_image->image_name != '' && file_exists($file_path)) {
                            ?>


                            <img class="thumbnail no-margin" src="<?= $this->config->item('uploads') ?>product_images/<?= $product_featured_image->image_name ?>" alt="<?= $category->category_name ?>" >

                        <?php } else { ?>
                            <img class="thumbnail no-margin" src="<<?= site_url('assets/uploads/product_images/image_not_available.jpg') ?>">
                        <?php } ?></a></div>
            </div>

            <div class="col-sm-6 add-desc-box">
                <div class="add-details">
                    <h5 class="add-title"><a href="<?= site_url('product/' . $product['slug']) ?>">
                            <?= $product['product_title'] ?> </a></h5>
                    <span class="info-row"> <span class="little-info">Services Available: A , B , C ,D</span> </span>
                    <div class="prop-info-box">
                        <div class="prop-info">
                            <div class="clearfix prop-info-block">
                                <span class="title ">2</span>
                                <span class="text">Services</span>
                            </div>
                            <div class="clearfix prop-info-block middle">
                                <span class="title">150</span>
                                <span class="text">Professionals</span>
                            </div>
                            <div class="clearfix prop-info-block">
                                <span class="title">2</span>
                                <span class="text">Cities</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-3 text-right  price-box">
                <!--   <a class="btn btn-border-thin  btn-save" title="save ads" data-toggle="tooltip" data-placement="left">
                       <i class="icon icon-heart"></i>
                   </a>
                   <a class="btn btn-border-thin  btn-share ">
                       <i class="icon icon-export" data-toggle="tooltip" data-placement="left" title="share"></i>
                   </a> -->
                <h3 class="item-price "> <strong>~ &#8377; 99 - &#8377; 2999 </strong></h3>
                <div style="clear: both"></div>
                <a class="btn btn-success btn-sm bold" href="<?= site_url('product/' . $product['slug']) ?>">
                    Check Services
                </a>
            </div>
        </div>
        <?php
    }
} else {
    ?>
    <p>No Products Found</p>
<?php } ?>

<script>
    $(document).ready(function () {
        $('#paging').html('<?= $paging ?>');
    });
</script>


