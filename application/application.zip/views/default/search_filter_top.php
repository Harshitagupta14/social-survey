<div class="search-row-wrapper">
    <div class="container ">
        <form action="#" method="GET">
            <div class="col-sm-3">
                <input class="form-control keyword" type="text" placeholder="e.g. Ac Repair">
            </div>
            <div class="col-sm-3">
                <select class="form-control selecter" name="category" id="search-category">
                    <option selected="selected" value="">All Categories</option>
                    <?php
                    $parent_categories_list = $this->product->get_categories(0);
                    foreach ($parent_categories_list as $parent_category) {
                        $sub_categories_list = $this->product->get_categories($parent_category['category_id']);
                        ?>
                        <option selected="selected" value="<?= $parent_category['category_name'] ?>"><?= $parent_category['category_name'] ?></option>

                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="col-sm-3">
                <select class="form-control selecter" name="location" id="id-location">
                    <option selected="selected" value="">All Locations</option>
                    <?php
                    $city_data = $this->common_model->getCityList();
                    if (!empty($city_data)) {
                        foreach ($city_data as $city) {
                            ?>
                            <option selected="selected" value="<?= $city['city_name'] ?>"><?= $city['city_name'] ?></option>
                        <?php
                        }
                    }
                    ?>
                </select>
            </div>
            <div class="col-sm-3">
                <button class="btn btn-block btn-primary  "><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>
</div>
