<link href="<?= $this->config->item('frontassets') ?>plugins/bxslider/jquery.bxslider.css" rel="stylesheet"/>
<?php echo $this->load->view($this->config->item('template') . '/search_filter_top') ?>
<div class="main-container">
    <div class="container">
        <ol class="breadcrumb pull-left">
            <li><a href="<?= site_url() ?>" ><i class="icon-home fa"></i></a></li>
            <?= $breadcrumb ?>
        </ol>
        <div class="pull-right backtolist"><a href="<?php echo site_url('category/' . $category_detail->slug); ?>"> <i class="fa fa-angle-double-left"></i> Back to Results</a></div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-9 page-content col-thin-right">
                <div class="inner inner-box ads-details-wrapper">
                    <h2> <?= $product_detail->product_title; ?>
                        <!--<small class="label label-default adlistingtype">150 Proffesionals Available</small>-->
                    </h2>
                    <div class="ads-image">
                        <h1 class="pricetag"> &#8377;<?php echo $product_detail->product_price; ?></h1>
                        <ul class="bxslider">
                            <?php foreach ($product_image as $image) { ?>

                                <li>

                                    <img  src="<?= $this->config->item('uploads') . 'product_images/' . $image['image_name'] ?>" alt="img" />

                                </li>

                            <?php } ?>
                        </ul>
                        <div id="bx-pager">
                            <?php
                            $i = 1;
                            foreach ($product_image as $image) {
                                ?>
                                <a class="thumb-item-link" data-slide-index="<?php echo $i; ?>" href="#">   <img  src="<?= $this->config->item('uploads') . 'product_images/' . $image['image_name'] ?>" alt="img" />
                                </a>

                            <?php } ?>
                        </div>
                    </div>

                    <div class="Ads-Details">
                        <h5 class="list-title"><strong>Service Details</strong></h5>
                        <div class="row">
                            <div class="ads-details-info col-md-8">
                                <p><?php echo $product_detail->product_description; ?></p>

                            </div>
                            <div class="col-md-4">

                                <div class="ads-action">
                                    <ul class="list-border">
                                        <li><a href="#"> <i class=" fa fa-user"></i> Similar Services </a></li>
                                        <li><a href="#"> <i class="fa fa-share-alt"></i> Share Service </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="content-footer text-left"><a class="btn  btn-default" data-toggle="modal" href="#contactAdvertiser"><i class=" icon-mail-2"></i> Book </a> <a class="btn  btn-info"><i class=" icon-phone-1"></i> Contact Directly </a></div>
                    </div>
                </div>

            </div>

            <div class="col-sm-3  page-sidebar-right">
                <aside>
                    <div class="panel sidebar-panel panel-contact-seller">
                        <div class="panel-heading">Book For Service</div>
                        <div class="panel-content user-info">
                            <div class="panel-body text-center">
                                <div class="seller-info">
                                    <h3 class="no-margin">Over 150 Proffessionals </h3>
                                    <p>Location: <strong>Pune</strong></p>
                                </div>
                                <div class="user-ads-action"><a href="#contactAdvertiser" data-toggle="modal" class="btn   btn-default btn-block"><i class=" icon-mail-2"></i> Book</a> <a class="btn  btn-info btn-block"><i class=" icon-phone-1"></i> Contact Directly
                                    </a></div>
                            </div>
                        </div>
                    </div>
                    <div class="panel sidebar-panel">
                        <div class="panel-heading">Quick Details</div>
                        <div class="panel-content">
                            <div class="panel-body text-left">
                                <ul class="list-check">
                                    <li> Min. Service Charge Rs.99</li>
                                    <li> Check for Original Parts before any replacement</li>
                                    <li> Pay only after receiving the service.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </aside>
            </div>

        </div>
    </div>
</div>

<div class="footer" id="footer">
    <div class="container">
        <ul class=" pull-left navbar-link footer-nav">
            <li><a href="index.html"> Home </a> <a href="about-us.html"> About us </a> <a href="terms-conditions.html"> Terms and
                    Conditions </a> <a href="#"> Privacy Policy </a> <a href="contact.html"> Contact us </a> <a href="faq.html"> FAQ </a>
        </ul>
        <ul class=" pull-right navbar-link footer-nav">
            <li> &copy; 2015 BootClassified</li>
        </ul>
    </div>
</div>

</div>


<div class="modal fade" id="reportAdvertiser" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title"><i class="fa icon-info-circled-alt"></i> There's something wrong with this ads?
                </h4>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="form-group">
                        <label for="report-reason" class="control-label">Reason:</label>
                        <select name="report-reason" id="report-reason" class="form-control">
                            <option value="">Select a reason</option>
                            <option value="soldUnavailable">Item unavailable</option>
                            <option value="fraud">Fraud</option>
                            <option value="duplicate">Duplicate</option>
                            <option value="spam">Spam</option>
                            <option value="wrongCategory">Wrong category</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="recipient-email" class="control-label">Your E-mail:</label>
                        <input type="text" name="email" maxlength="60" class="form-control" id="recipient-email">
                    </div>
                    <div class="form-group">
                        <label for="message-text2" class="control-label">Message <span class="text-count">(300) </span>:</label>
                        <textarea class="form-control" id="message-text2"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary">Send Report</button>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="contactAdvertiser" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title"><i class=" icon-mail-2"></i> Contact advertiser </h4>
            </div>
            <div class="modal-body">
                <form role="form">
                    <div class="form-group">
                        <label for="recipient-name" class="control-label">Name:</label>
                        <input class="form-control required" id="recipient-name" placeholder="Your name" data-placement="top" data-trigger="manual" data-content="Must be at least 3 characters long, and must only contain letters." type="text">
                    </div>
                    <div class="form-group">
                        <label for="sender-email" class="control-label">E-mail:</label>
                        <input id="sender-email" type="text" data-content="Must be a valid e-mail address (user@gmail.com)" data-trigger="manual" data-placement="top" placeholder="email@you.com" class="form-control email">
                    </div>
                    <div class="form-group">
                        <label for="recipient-Phone-Number" class="control-label">Phone Number:</label>
                        <input type="text" maxlength="60" class="form-control" id="recipient-Phone-Number">
                    </div>
                    <div class="form-group">
                        <label for="message-text" class="control-label">Message <span class="text-count">(300) </span>:</label>
                        <textarea class="form-control" id="message-text" placeholder="Your message here.." data-placement="top" data-trigger="manual"></textarea>
                    </div>
                    <div class="form-group">
                        <p class="help-block pull-left text-danger hide" id="form-error">&nbsp; The form is not
                            valid. </p>
                    </div>
                </form>
            </div>


            <script src="<?= $this->config->item('frontassets') ?>plugins/bxslider/jquery.bxslider.min.js"></script>
            <script>
                $('.bxslider').bxSlider({
                    pagerCustom: '#bx-pager'
                });
            </script>