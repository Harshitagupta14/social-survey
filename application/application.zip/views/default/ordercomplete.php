<section class="content_section">
    <div class="container">
        <div class="alert alert-success" id="successMsg" style="display:none;">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Success! </strong> Quantity Updated Successfully.
        </div>
        <?php if ($this->session->flashdata('ProductSuccess')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('ProductSuccess') ?></div>
        <?php } ?>
        <ul class="steps">
            <li>Shopping Cart</li>
            <li>Shipping</li>
            <li>Order Review</li>
            <li class="current">Order Complete</li>
        </ul>
        <h2>Order Confirmation Detail</h2>
        <center>
            <h4>Thank you for your Order</h4> 
            <br />
            <strong>Order NO is: <?php echo $this->session->userdata('order_id'); ?><br />                           
                You will Receive an email confirmation shortly For Your Order. please save this order number for future references and tracking of order.</strong><br />
            <br />
        </center>
        <br />
        <div class="table-responsive">

            <table cellspacing="0" cellpadding="0" border="0" class="table table-bordered table-striped cart_table">
                <tr>
                    <th width="70">Product Image</th>
                    <th width="100">Product Title</th>                   
                    <th width="100">UPC Code</th>
                    <th width="100">Product Code</th>
                    <th width="80">Price</th>
                    <th width="80">Quantity</th>
                    <th width="80">Total</th>
<!--                    <th width="50">Action</th>-->
                </tr>
                <?php
                foreach ($orderItems as $order) {
                    //$product_data = $obj_product->findByPk($order->product_id);
                    ?> 
                    <tr>
                        <td>
                            <?php
                            $file_path = FCPATH . "assets/uploads/product_images/" . $order->product_image;
                            if ($order->product_image != '' && file_exists($file_path)) {
                                ?>
                                <a class="fancybox" href="<?= $this->config->item('uploads') ?>product_images/<?= $order->product_image ?>">
                                    <img width="100" height="100" class="media-object"  src="<?= site_url('assets/uploads/product_images/' . $order->product_image) ?>" alt="<?= $order->product_title ?>" >
                                </a>
                            <?php } else { ?>
                                <img width="100" height="100" src="<?= site_url('assets/uploads/product_images/image_not_available.jpg') ?>">
                            <?php } ?>                                                       
                        </td>
                        <td><?= $order->product_title ?></td>                   
                        <td><?= $order->product_upc_code ?></td>
                        <td><?= $order->product_code ?></td>
                        <td>$<?= $order->unit_product_price ?></td>
                        <td> <?= $order->product_quantity ?></td>
                        <td><big>$<?= $order->total_product_price ?></big></td>
    <!--                        <td align="center">
                        <a href="<?= DEFAULT_URL ?>/cart/delete?id=<?= $order->cart_id ?>" class="btn btn-inverse btn-sm"><i class="fa fa-times"></i></a>
                    </td>-->
                    </tr>
                <?php } ?>
                <tr>
                    <td colspan="6" align="right">Sub-Total:</td>
                    <td>$<?= $order_detail['sub_total']; ?></td>
                </tr>
                <?php if ($order_detail['discount'] != 0) { ?>
                    <tr>
                        <td colspan="6" align="right">Discount:</td>
                        <td>$<?php echo $order_detail['discount'] ?></td>

                    </tr>
                    <tr>
                        <td colspan="6" align="right">Total-Amount:</td>
                        <td>$<?= $order_detail['total_amount']; ?></td> 
                    </tr>
                <?php } ?>    </table>
        </div>
    </div>
</section>
<script>
    $('body').delegate('.updateCart', 'click', function () {
        var product_id = $(this).attr('data-product_id');
        var product_price = $(this).attr('data-product_price');
        var quantity = $(this).parent().parent().children().find('.qty-input').val();
        if (quantity != '') {

            $.ajax({
                type: "POST",
                async: 'false',
                url: "<?php echo site_url('updatecart') ?>",
                // dataType: "html",
                data: {"product_id": product_id, "product_quantity": quantity, "product_price": product_price},
                success: function (msg) {
                    // location.reload(); 
                    $('#itemQuantity').text(msg + ' Item');
                    $('#successMsg').show().delay(10000).fadeOut();
                }
            })
        } else {
            alert("Please Update Quantity Of Items");
        }

    });
</script>