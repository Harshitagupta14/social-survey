<?php if ($this->flexi_auth->is_logged_in()) { ?>
    <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
        <div class="row form-group">
            <div class="col-md-6"><input type="text" name="full_name" class="form-control" placeholder="Name" required></div>
            <div class="col-md-6"><input type="email" name="email" class="form-control" placeholder="Email" required></div>
        </div>
        <div class="row form-group">

            <div class="col-md-12"><input type="text" name="subject" class="form-control" placeholder="Subject" required></div>
        </div>
        <div class="row form-group">
            <div class="col-md-12"><textarea class="form-control " name="review" placeholder="Message" required></textarea></div>
        </div>
        <div class="row form-group">
            <div class="col-md-6"> <input type="submit" name="" class="btn btn-success" value="Post Comment"></div>
        </div>
    </form>
<?php } else { ?>
    <p> Please login before reviewing the product.</p>
<?php } ?>