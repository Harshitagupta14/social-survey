<div class="col-sm-12 col-sm-3">
    <?php
    $blogcategory_data = $this->common_model->getBlogCategory();
    $recent_blog_data = $this->common_model->getRecentBlog();
    ?>
    <div class="sidebar">
        <h1>Categories</h1>
        <ul>
            <?php foreach ($blogcategory_data as $category) { ?>
                <li><a href="<?= site_url('blog-category/' . $category['slug']) ?>"><?= $category['bg_category_title']; ?></a></li>
            <?php } ?>
        </ul>  
        <br>
        <h1>Recent Posts</h1>
        <ul>
            <?php foreach ($recent_blog_data as $recent_blog) { ?>
                <li><a href="<?= site_url('blog/' . $recent_blog['slug']) ?>"><?= $recent_blog['blog_title']; ?></a></a></li>
            <?php } ?>
        </ul>
    </div>
</div>