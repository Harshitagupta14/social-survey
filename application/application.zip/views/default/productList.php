<?php echo $this->load->view($this->config->item('template') . '/search_filter_top') ?>
<div class="main-container">
    <div class="container">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="<?= site_url() ?>" ><i class="icon-home fa"></i></a></li>
                <?= $breadcrumb ?>
            </ol>
        </div>
        <div class="row">
            <?php echo $this->load->view($this->config->item('template') . '/categoryList') ?>
            <div class="col-sm-9 page-content col-thin-left">
                <div class="category-list">


                    <div class="listing-filter">
                        <div class="pull-right col-xs-6 text-right listing-view-action"><span class="list-view active"><i class="  icon-th"></i></span> <span class="compact-view"><i class=" icon-th-list  "></i></span> <span class="grid-view "><i class=" icon-th-large "></i></span></div>
                        <div style="clear:both"></div>
                    </div>


                    <div class="mobile-filter-bar col-lg-12  ">
                        <ul class="list-unstyled list-inline no-margin no-padding">
                            <li class="filter-toggle">
                                <a class="">
                                    <i class="  icon-th-list"></i>
                                    Filters
                                </a>
                            </li>
                            <li>
                                <div class="dropdown">
                                    <a data-toggle="dropdown" class="dropdown-toggle"><i class="caret "></i> Short
                                        by </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#" rel="nofollow">Relevance</a></li>
                                        <li><a href="#" rel="nofollow">Date</a></li>
                                        <li><a href="#" rel="nofollow">Company</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="menu-overly-mask"></div>

                    <div class="adds-wrapper property-list">
                        <div id="my-list"></div>
                        <div id="paging"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<?= $this->load->view($this->config->item('template') . '/mytable'); ?>
<script>
    $("body").delegate(".grid_view", "click", function (e) {
        e.preventDefault();
        $(this).addClass("active");
        $(".list_view").removeClass("active");
        $('.item-list').each(function (i, obj) {
            $('.item-list').addClass("make-grid");
        });
        $(".item-list").addClass("make-grid");

    });
    $("body").delegate(".list_view", "click", function (e) {
        e.preventDefault();
        $(this).addClass("active");
        $(".grid_view").removeClass("active");
        $("#my-list").switchClass("grid-view", "list-view");
    });
    $('body').delegate('.addToCart', 'click', function () {
        var product_id = $(this).attr('data-product_id');
        var category_id = $(this).attr('data-category_id');
        var product_title = $(this).attr('data-product_title');
        var product_description = $(this).attr('data-product_description');
        var product_upc_code = $(this).attr('data-product_upc_code');
        var product_code = $(this).attr('data-product_code');
        var product_price = $(this).attr('data-product_price');
        //  alert(product_size);
        var product_color = $(this).parent().parent().children().find('.color-input').val();
        var quantity = $(this).parent().parent().parent().children().find('.quantity').val();
        if (quantity != '' && product_color != 'Select Color') {

            $.ajax({
                type: "POST",
                async: 'false',
                url: baseurl + "add-cart-item",
                // dataType: "html",
                data: {"product_id": product_id, "category_id": category_id, "product_color": product_color, "product_quantity": quantity},
                success: function (msg) {
                    $('#itemQuantity').text(msg + ' Item');
                    $('#successMsg').show().delay(5000).fadeOut();
                    $('html,body').animate({scrollTop: $('#scrollToTop').offset().top}, 'slow');
                    $(this).parent().parent().children().find('.qty-input').val('');
                }
            })
        }
        else {
            alert("Please Check Fields");
        }
    });
    $("body").delegate(".checkbox", "click", function () {

        var checkedValue = $('#product_id:checked').val();
        alert(checkedValue);

        $.ajax({
            type: "POST",
            async: 'false',
            url: baseurl + "add-compare-item",
            // dataType: "html",
            data: {"product_id": checkedValue, },
            success: function (msg) {

                alert("product added to comparison list");
                location.reload();
            }
        })


    });




    //
    //    alert(arr);
    ////
    // if(arr){
    //
    $("body").delegate(".increment_qty", "click", function () {
        var oldVal = $(this).parent().find(".quantity").val();
        // alert(oldVal);die;
        if (parseInt(oldVal) >= 1) {
            var newVal = parseInt(oldVal) + 1;
            $(this).parent().find(".quantity").val(newVal);
        }
    });
    $("body").delegate(".decrement_qty", "click", function () {
        var oldVal = $(this).parent().find(".quantity").val();
        if (parseInt(oldVal) >= 2) {
            var newVal = parseInt(oldVal) - 1;
            $(this).parent().find(".quantity").val(newVal);
        }
    });
</script>