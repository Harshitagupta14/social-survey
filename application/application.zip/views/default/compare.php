<section class="content_section">
    <div class="mid">
        <div class="container">
            <div class="row">
                <?php echo $this->load->view($this->config->item('template') . '/categoryList') ?>
                <!-- right bar -->
                <div class="col-sm-12 col-md-9 cat_bar">
                    <ol class="breadcrumb">
                        <li><a href="<?= site_url() ?>">Home</a> </li>
                        <?= $breadcrumb ?>
                    </ol>

                    <div class="clearfix"></div>

                    <table class="compare-table" width="100%">
                        <tr>
                            <th>&nbsp;</th>
                            <th>
                                <h3>Moto G (3rd Generation)</h3>
                                <img src="<?= $this->config->item('frontassets') ?>img/product_01.jpg" alt="product">
                            </th>
                            <th>
                                <h3>Lenevo A6000 Plus</h3>
                                <img src="<?= $this->config->item('frontassets') ?>img/product_02.jpg" alt="product">
                            </th>
                        </tr>
                        <tr>
                            <td>Price</td>
                            <td><big class="text-primary">$300.00</big></td>
                            <td><big class="text-primary">$350.00</big></td>
                        </tr>
                        <tr>
                            <td>Other Colors</td>
                            <td>
                                <span class="colors" style="background:#ffffff"></span>
                                <span class="colors" style="background:#000000"></span>
                            </td>
                            <td>
                                <span class="colors" style="background:#ffffff"></span>
                                <span class="colors" style="background:#000000"></span>
                            </td>
                        </tr>
                        <tr>
                            <td>UPC Code</td>
                            <td>0101010451021</td>
                            <td>0101010451021</td>
                        </tr>
                        <tr>
                            <td>Product Code</td>
                            <td>TEMP-1021</td>
                            <td>TEMP-1021</td>
                        </tr>
                        <tr>
                            <td class="compare_heading" colspan="3">GENERAL SPECIFICATION</td>
                        </tr>
                        <tr>
                            <td>Touch Screen</td>
                            <td>Capatitive</td>
                            <td>Capatitive</td>
                        </tr>
                        <tr>
                            <td>Sim Type</td>
                            <td>Duel Sim, GSM + LTE</td>
                            <td>Duel Sim, GSM + LTE</td>
                        </tr>
                        <tr>
                            <td>Video Calling</td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                        </tr>
                        <tr>
                            <td>FLASH</td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                        </tr>
                        <tr>
                            <td>ZOOM</td>
                            <td>Digital</td>
                            <td>Digital</td>
                        </tr>
                        <tr>
                            <td>HD RECORDING</td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                        </tr>
                        <tr>
                            <td>REAR CAMERA</td>
                            <td>13 MP</td>
                            <td>8 MP</td>
                        </tr>
                        <tr>
                            <td>MUSIC PLAYER</td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                        </tr>
                        <tr>
                            <td>FM</td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                        </tr>
                        <tr>
                            <td>4G</td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                            <td><i class="fa fa-check fa-2x"></i></td>
                        </tr>
                        <tr>
                            <td>PROCESSER</td>
                            <td>1.4 GHZ</td>
                            <td>1.4 GHZ</td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td><a href="#" class="btn btn-add-cart">Add To Cart</a></td>
                            <td><a href="#" class="btn btn-add-cart">Add To Cart</a></td>
                        </tr>
                    </table>
                </div>        
            </div>
        </div>
    </div>  
</section>