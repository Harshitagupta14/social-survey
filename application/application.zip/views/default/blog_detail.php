<section class="content_section">
    <div class="container">
        <div class="row">
            <?php $this->load->view($this->config->item('template') . '/blog-rightbar'); ?>
            <div class="col-sm-9">
                <ol class="breadcrumb">
                    <li><a href="<?= site_url() ?>">Home</a> </li>
                    <li><a href="<?= site_url('blog') ?>">Blog</a> </li>
                    <li class="active"><?= $blog_detail->blog_title ?></li>
                </ol>
                <div class="grid_bar">
                    <h4><?= $blog_detail->blog_title ?></h4>
                </div>
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12">
                        <article class="blog_detail">
                            <?php
                            if($blog_detail->show_image == 'yes'){
                            $file_path = FCPATH . "assets/uploads/blog_images/" . $blog_detail->blog_image;
                            if ($blog_detail->blog_image != '' && file_exists($file_path)) {
                                ?>
                                <a class="fancybox" href="<?= $this->config->item('uploads') ?>blog_images/<?= $blog_detail->blog_image ?>">
                                    <img class="img-responsive"  src="<?= site_url('assets/uploads/blog_images/' . $blog_detail->blog_image) ?>" alt="<?= $blog_detail->blog_title ?>" >
                                </a>
                            <?php }} ?>       
                            <h6>Posted on <i class="fa fa-calendar"></i> <?= date('d M Y', $blog_detail->add_time); ?> by <i class="fa fa-user"></i> Admin</h6>
                            <p><?= $blog_detail->blog_description; ?></p>               
                            <h4>Comments</h4>
                            <?php
                            if (isset($blogComments) && !empty($blogComments)) {
                                foreach ($blogComments as $blogComment) {//pr($blogComment);die;
                                    ?>
                                    <blockquote>
                                        <span><i class="fa fa-user"></i> <?= $blogComment['full_name']; ?></span>
                                        "<?= $blogComment['comment']; ?>"
                                    </blockquote>
                                    <?php
                                }
                            } else {
                                ?>
                                <blockquote>
                                    "There Is No Comments For This Blog"
                                </blockquote>
                            <?php } ?>
                            <div class="comment_Form">
                                <h4>Leave Comment</h4>
                                <form action="" class="form-horizontal" method="post" enctype="multipart/form-data">
                                    <div class="row form-group">
                                        <div class="col-md-6"><input type="text" name="full_name" class="form-control" placeholder="Name" required></div>
                                        <div class="col-md-6"><input type="email" name="email" class="form-control" placeholder="Email" required></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-md-6"><input type="text" name="phone" class="form-control" placeholder="Phone" required></div>
                                        <div class="col-md-6"><input type="text" name="subject" class="form-control" placeholder="Subject" required></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-md-6"><textarea class="form-control " name="comment" placeholder="Message" required></textarea></div>
                                        <div class="col-md-6"> <input type="submit" name="" class="btn btn-success" value="Post Comment"></div>
                                    </div>
                                </form>
                            </div>
                        </article>
                    </div> 
                </div> 
            </div> 
        </div>
    </div>
</section>
<script>
    $('body').delegate('.comment', 'click', function () {
        var name = $('.name').val();
        var email = $('.email').val();
        var phone = $('.phone').val();
        var message = $('.message').val();
        if (name != '' && email != '' && message != '') {
            $.ajax({
                type: "POST",
                async: 'false',
                url: "<?= site_url('blog-comment') ?>",
                data: {"full_name": name, "email": email, "phone": phone, "comment": message},
                dataType: 'json',
                success: function (msg) {
                    alert(msg);
                }
            })
        }
    });
</script>