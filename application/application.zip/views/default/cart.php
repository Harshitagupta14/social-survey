<section class="content_section" id="full_cart">
    <div class="container" id="scrollToTop">
        <div class="alert alert-success" id="successMsg" style="display:none;">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong>Success! </strong> Quantity Updated Successfully.
        </div>
        <?php if ($this->session->flashdata('ProductSuccess')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('ProductSuccess') ?></div>
        <?php } ?>
        <?php if ($this->session->flashdata('DeleteSuccess')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('DeleteSuccess') ?></div>
        <?php } ?>
        <?php if ($this->session->flashdata('EmptySuccess')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('EmptySuccess') ?></div>
        <?php } ?>  
        <?php if ($this->session->flashdata('QuantitySuccess')) { ?>  
            <div class="alert alert-success"> <?= $this->session->flashdata('QuantitySuccess') ?></div>
        <?php } ?>     

        <ul class="steps">
            <li class="current">Shopping Cart</li>
            <li>Shipping</li>
            <li>Order Review</li>
            <li>Order Complete</li>
        </ul>
        <div class="table-responsive" id="cart">
            <form name="cart_update" id="cart_update" method="POST" action="update-item-quantity">
                <table cellspacing="0" cellpadding="0" border="0" class="table table-bordered table-striped cart_table">
                    <tr>
                        <th width="70">Product Image</th>
                        <th>Product</th>        
                        <th width="100">Code</th>
                        <th width="100">UPC Code</th>
                        <th width="80">Price</th>
                        <th width="100">Quantity</th>
                        <th width="80">Total</th>
                        <th width="130">Action</th>
                    </tr>
                    <?php
                    $cart_data = $this->cart->getCartItemDetail();
                    $cart_detail = $this->cart->getCartDetail();
                    $country_list = $this->common_model->getCountryList();
                    if (isset($cart_data) && !empty($cart_data)) {
                        foreach ($cart_data as $cart) { 
                            $product = $this->cart->getProductDetail($cart['product_id']);
                            $product_image = $this->product->get_product_featured_image($product->product_id);
                            ?>
                            <tr>
                                <td>
                                    <?php
                                    $file_path = FCPATH . "assets/uploads/product_images/" . $product_image->image_name;
                                    if ($product_image->image_name != '' && file_exists($file_path)) {
                                        ?>
                                        <a class="fancybox fancybox.iframe" href="<?= $this->config->item('uploads') ?>product_images/<?= $product_image->image_name ?>">
                                            <img width="50" height="50" class="media-object"  src="<?= site_url('assets/uploads/product_images/' . $product_image->image_name) ?>" alt="<?= $product->product_name ?>" >
                                        </a>
                                    <?php } else { ?>
                                        <img width="50" height="50" src="<?= site_url('assets/uploads/product_images/image_not_available.jpg') ?>">
                                    <?php } ?>           
                                </td>
                                <td><?= $cart['product_title']; ?><br/><?php if( $cart['product_color']!='0' ){?>Color:(<?= $cart['product_color']; ?>)<?php } ?></td>
                                <td><?= $cart['product_code']; ?></td>
                                <td><?= $cart['product_upc_code']; ?></td>
                                <td><?= $product->product_price; ?></td>
                                <td width="120">
                                    <div class="input-group">
                                        <span class="input-group-btn">
                                            <button class="btn btn-default decrement_qty" type="button">-</button>
                                        </span>
                                        <input class="form-control quantity qty-input" type="text" name="product_quantity[<?= $cart['cart_item_id'] ?>]" value="<?= $cart['product_quantity']; ?>">
                                        <span class="input-group-btn">
                                            <button class="btn btn-default increment_qty" type="button">+</button>
                                        </span>
                                    </div> 
                                </td>
                                <td><big><?= $cart['total_product_price']; ?></big></td>
                            <td align="center">
                                <a href="<?= site_url('delete-cart-item/' . $cart['cart_item_id'] . '') ?>" data-href="" class="btn btn-danger btn-rounded btn-condensed btn-sm" data-id="<?= $key ?>"><span class="fa fa-times" title="delete"></span></a>
                            </td>
                            </tr> 
                        <?php } ?>
                        <tr>
                            <td colspan="7"  align="right">Sub-Total:</td>
                            <td><?= $this->config->item('site_currency'); ?> <?= $cart_detail['sub_total']; ?></td>
                        </tr>
                        <tr>
                            <td colspan="3" align="right">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="coupon_code" placeholder="Enter Coupon Code" />  
                                    <span class="input-group-btn">
                                        <input type="button" class="btn btn-success" id="saveCoupon" value="Apply">
                                    </span>
                                </div>                           
                            </td>
                            <td colspan="4" align="right"><?php if ($cart_detail['coupon_per'] != 0.00) { ?>(Discount Percentage: <?= $cart_detail['coupon_per']; ?>% )<?php } ?> Discount:</td>

                            <td><?= $this->config->item('site_currency'); ?> <?= $cart_detail['total_discount']; ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" rowspan="1" align="right center">
                                <div class="col-md-3">
                                    <select class="form-control select" data-live-search="true" name="country_id" id="country_id">  
                                        <option>Select Country</option>
                                        <?php foreach ($country_list as $country) { ?>
                                            <option value="<?= $country['ct_id'] ?>"<?php if ($country['ct_id'] == $country_id) { ?> selected="selected" <?php } ?>><?= $country['country_name'] ?></option>  
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <select class="form-control select" data-live-search="true" name="province_id" id="province"> 
                                        <option>Select Country First</option>

                                        <?php foreach ($province_list as $province) { ?>
                                            <option value="<?= $province['province_id'] ?>"<?php if ($province['province_id'] == $province_id) { ?> selected="selected" <?php } ?>><?= $province['province_name'] ?></option>  
                                        <?php } ?>
                                    </select>
                                </div>
                                <div>
                                    <a class="btn btn-success" id="saveTax" href="javascript:;">Apply</a>
                                </div>
                            </td>
                            <td colspan="3" id="gst_tax_perc" align="right">GST Amount (<?php echo $cart_detail['gst_per'] ?> %) :</td>
                            <td id="gst_tax_value"><?= $this->config->item('site_currency'); ?> <?php echo $cart_detail['gst'] ?></td>
                        </tr>
<!--                        <tr>
                            <td colspan="3" id="pst_tax_perc" align="right">PST Amount (<?php echo $cart_detail['pst_per'] ?> %) :</td>
                            <td id="pst_tax_value"><?= $this->config->item('site_currency'); ?> <?php echo $cart_detail['pst'] ?></td>
                        </tr>
                        <tr>
                            <td colspan="3" id="hst_tax_perc" align="right">HST Amount (<?php echo $cart_detail['hst_per'] ?> %) </td>
                            <td id="hst_tax_value"><?= $this->config->item('site_currency'); ?> <?php echo $cart_detail['hst'] ?></td>
                        </tr>-->
                        <tr>
                            <td colspan="7" align="right">Total Payable Amount:</td>
                            <td id="total_value"><?= $this->config->item('site_currency'); ?> <?php echo $cart_detail['total_cart_price'] ?></td>
                        </tr>
                        <?php
                    } else {
                        ?>
                        <tr>
                            <td colspan="8" align="center">There Is No Items In Your Shopping Cart</td>
                        </tr>
                    <?php } ?>
                </table>
                <div class="text-right">
                    <a href="<?= site_url('empty-cart') ?>" class="btn btn-danger">Empty Your Cart</a>
                    <a href="<?= site_url('category') ?>" class="btn btn-success">Continue Shopping</a>
                    <input type="submit" name="update_cart"  class="btn btn-success updateQuantity" value="Update Cart" />
                    <a href="<?= site_url('shipping') ?>" class="btn btn-success">Checkout</a>  
                </div>
            </form>
        </div>
    </div>
</section>
<script>
    $("body").delegate(".increment_qty", "click", function () {
        var oldVal = $(this).parent().parent().find(".qty-input").val();
        if (parseInt(oldVal) >= 1) {
            var newVal = parseInt(oldVal) + 1;
            $(this).parent().parent().find(".qty-input").val(newVal);
        }
    });
    $("body").delegate(".decrement_qty", "click", function () {
        var oldVal = $(this).parent().parent().find(".qty-input").val();
        if (parseInt(oldVal) >= 2) {
            var newVal = parseInt(oldVal) - 1;
            $(this).parent().parent().find(".qty-input").val(newVal);
        }
    });
</script>